import { describe, expect, it } from 'vitest';
import { AREAS, CLASS_MAX_KN, historyAt, ORIGIN } from '../src/data/world.js';
import { fromLocalNm } from '../src/domain/geo.js';
import { detectAirCircle, detectAll, detectDark, detectJump, detectLoiter, detectMeetings, detectSpeed, levelOf } from '../src/domain/anomalies.js';
import { makeDecision, recommend, stats, statusOf, validateDecision } from '../src/domain/decisions.js';

const T0 = Date.parse('2026-11-14T11:00:00Z');
const H = historyAt(T0, T0);
const byId = (id) => H.find((h) => h.id === id);
const ids = (list) => list.map((a) => `${a.id}=${a.score}`);
const P = (min, x, y, sog = 5, cog = 0, extra = {}) => {
  const [lon, lat] = fromLocalNm([x, y], ORIGIN);
  return { ts: new Date(T0 - (40 - min) * 60000).toISOString(), lon, lat, sog, cog, ...extra };
};
const track = (points, o = {}) => ({ id: 'trk-x', name: 'X', domain: 'sea', kind: 'cargo', classification: 'neutral', source: 'ais', points, ...o });

describe('сценарій імітатора', () => {
  it('на початку: п\'ять вагомих аномалій і одна низька', () => {
    expect(ids(detectAll(H, AREAS, CLASS_MAX_KN))).toEqual([
      'dark:trk-6104=70', 'air_circle:trk-7101=70', 'rendezvous:trk-6102+trk-6103=70',
      'loiter:trk-6101=65', 'jump:trk-6105=55', 'loiter:trk-6107=15',
    ]);
  });
  it('звичайні судна і вертоліт у секторі аеродрому аномалій не мають', () => {
    const all = detectAll(H, AREAS, CLASS_MAX_KN).flatMap((a) => a.trackIds);
    for (const id of ['trk-6106', 'trk-6108', 'trk-7102', 'trk-7103']) expect(all).not.toContain(id);
  });
  it('через 15 хв розрив AIS виходить з 40-хвилинної історії', () => {
    const later = detectAll(historyAt(T0 + 15 * 60000, T0), AREAS, CLASS_MAX_KN).map((a) => a.id);
    expect(later).not.toContain('dark:trk-6104');
    expect(later).toContain('rendezvous:trk-6102+trk-6103');
  });
});

describe('ознаки', () => {
  it('кружляння над трубопроводом: +30 за критичний об\'єкт', () => {
    const a = detectLoiter(byId('trk-6101'), AREAS);
    expect(a.indicators.map((i) => i.code)).toEqual(['loiter', 'near_critical']);
  });
  it('кружляння в рибальському районі: поправка −20', () => {
    const a = detectLoiter(byId('trk-6107'), AREAS);
    expect(a).toMatchObject({ score: 15, level: 'low' });
  });
  it('пряме судно не кружляє', () => {
    expect(detectLoiter(byId('trk-6106'), AREAS)).toBeNull();
  });
  it('розрив AIS і швидкість, неможлива для класу', () => {
    const a = detectDark(byId('trk-6104'), CLASS_MAX_KN);
    expect(a.indicators.map((i) => i.code)).toEqual(['dark', 'speed_class']);
    expect(a.gapMin).toBe(15);
  });
  it('короткий розрив — не аномалія', () => {
    expect(detectDark(track([P(0, 10, 10), P(4, 10.5, 10)]), CLASS_MAX_KN)).toBeNull();
  });
  it('стрибок з поверненням — ознака підміни', () => {
    expect(detectJump(byId('trk-6105')).indicators.map((i) => i.code)).toEqual(['jump', 'returned']);
  });
  it('зустріч: двоє стоять поруч 10+ хв, одне без AIS', () => {
    const [m] = detectMeetings(H, AREAS);
    expect(m.trackIds).toEqual(['trk-6102', 'trk-6103']);
    expect(m.indicators.map((i) => i.code)).toEqual(['meet', 'partner_dark']);
  });
  it('зустріч на якірній стоянці — норма', () => {
    const a = track([0, 4, 8, 12].map((m) => P(m, 18, 22, 0)), { id: 'a' });
    const b = track([0, 4, 8, 12].map((m) => P(m, 18.1, 22, 0)), { id: 'b' });
    expect(detectMeetings([a, b], AREAS)).toEqual([]);
  });
  it('нетипова швидкість для класу', () => {
    expect(detectSpeed(track([P(39, 30, 10, 25)], { kind: 'fishing' }), CLASS_MAX_KN).score).toBe(30);
    expect(detectSpeed(track([P(39, 30, 10, 12)], { kind: 'fishing' }), CLASS_MAX_KN)).toBeNull();
  });
  it('кружляння в повітрі на малій висоті', () => {
    expect(detectAirCircle(byId('trk-7101'), AREAS).indicators.map((i) => i.code)).toEqual(['circling', 'low', 'unknown']);
  });
  it('пороги рівнів', () => {
    expect([levelOf(70), levelOf(69), levelOf(40), levelOf(39)]).toEqual(['high', 'medium', 'medium', 'low']);
  });
});

describe('рішення', () => {
  const a = { id: 'loiter:trk-1', type: 'loiter', trackIds: ['trk-1'], score: 65, level: 'medium' };
  it('рекомендація залежить від типу, рівня і наявності AIS', () => {
    expect(recommend(a, { hasAis: true }).action).toBe('contact');
    expect(recommend(a, { hasAis: false }).action).toBe('verify');
    expect(recommend({ ...a, type: 'rendezvous', level: 'high' }, {}).action).toBe('verify');
    expect(recommend({ ...a, type: 'air_circle', level: 'high' }, {}).action).toBe('escalate');
    expect(recommend({ ...a, level: 'low' }, {}).action).toBe('watch');
  });
  it('без обґрунтування, «інше» без примітки, спостереження без строку — помилки', () => {
    expect(validateDecision({ action: 'verify' })).toHaveProperty('reason');
    expect(validateDecision({ action: 'verify', reason: 'other', note: '' })).toHaveProperty('note');
    expect(validateDecision({ action: 'watch', reason: 'score' })).toHaveProperty('minutes');
    expect(validateDecision({ action: 'watch', reason: 'score', minutes: 30 })).toEqual({});
  });
  it('стан: спостереження до строку, потім знову на рішення', () => {
    const d = makeDecision(a, { action: 'watch', reason: 'score', minutes: 30, recommended: 'contact' }, T0);
    expect(d.followed).toBe(false);
    expect(statusOf(a, d, T0 + 10 * 60000)).toBe('watch');
    expect(statusOf(a, d, T0 + 31 * 60000)).toBe('expired');
  });
  it('визнане нормою повертається, якщо оцінка зросла на 15 і більше', () => {
    const d = makeDecision(a, { action: 'dismiss', reason: 'known_activity', recommended: 'contact' }, T0);
    expect(statusOf(a, d, T0 + 1000)).toBe('decided');
    expect(statusOf({ ...a, score: 80 }, d, T0 + 1000)).toBe('escalated');
    expect(statusOf(a, d, T0 + 3 * 3600000)).toBe('new');
  });
  it('статистика розбору за типами', () => {
    const mk = (type, review, followed = true) => ({ type, review, followed });
    expect(stats([mk('loiter', 'refuted'), mk('loiter', 'confirmed'), mk('loiter', null, false), mk('dark', 'confirmed')])).toEqual([
      { type: 'loiter', total: 3, reviewed: 2, refuted: 1, followed: 2, refutedShare: 50 },
      { type: 'dark', total: 1, reviewed: 1, refuted: 0, followed: 1, refutedShare: 0 },
    ]);
  });
});
