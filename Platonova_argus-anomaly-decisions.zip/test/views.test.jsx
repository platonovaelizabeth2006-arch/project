import { act, screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { describe, expect, it } from 'vitest';
import { location, renderApp } from './helpers.jsx';

const queue = () => within(screen.getByRole('list', { name: 'Аномалії' })).getAllByRole('listitem');
const ready = () => screen.findByRole('img', { name: /Карта аномалій/ });

describe('Аномалії руху', () => {
  it('стан завантаження', () => {
    renderApp('/anomalies', { scenario: 'loading' });
    expect(screen.getByLabelText('Завантаження карти')).toBeInTheDocument();
  });
  it('стан даних: вагомі першими, з рекомендацією', async () => {
    renderApp('/anomalies');
    await ready();
    expect(queue()).toHaveLength(6);
    expect(queue()[0]).toHaveTextContent('Вимкнення AIS');
    expect(queue()[0]).toHaveTextContent('радимо: направити засіб для перевірки');
    expect(screen.getByRole('link', { name: 'Потребують рішення: 6' })).toBeInTheDocument();
  });
  it('стан помилки', async () => {
    renderApp('/anomalies', { scenario: 'error' });
    expect(await screen.findByRole('alert')).toHaveTextContent('не тому, що їх немає');
  });
  it('порожньо: немає треків і аномалій', async () => {
    renderApp('/anomalies', { scenario: 'empty' });
    expect(await screen.findByText('Аномалій не виявлено')).toBeInTheDocument();
    expect(screen.getByText('У районі зараз немає треків')).toBeInTheDocument();
  });
  it('вибір на карті клавіатурою зберігається в адресі', async () => {
    renderApp('/anomalies');
    await ready();
    screen.getByRole('button', { name: 'UR-LKT: air_circle:trk-7101' }).focus();
    await userEvent.keyboard('{Enter}');
    expect(location().search).toBe('?a=air_circle%3Atrk-7101');
  });
  it('оновлення припинилися', async () => {
    const { store } = renderApp('/anomalies');
    await ready();
    act(() => store.setState({ stale: { message: 'обрив' } }));
    expect(screen.getByText('Оновлення обстановки припинилися')).toBeInTheDocument();
  });
});

describe('Картка рішення', () => {
  it('оцінка розкладена на ознаки', async () => {
    renderApp('/anomalies/loiter%3Atrk-6101');
    const ev = await screen.findByRole('table', { name: 'З чого складається оцінка' });
    expect(ev).toHaveTextContent('Кружляє на місці понад 20 хв');
    expect(ev).toHaveTextContent('Над критичним об\'єктом');
    expect(ev).toHaveTextContent('Разом (від 0 до 100)65');
  });
  it('рекомендація попередньо обрана; без обґрунтування не ухвалити', async () => {
    renderApp('/anomalies/rendezvous%3Atrk-6102%2Btrk-6103');
    expect(await screen.findByRole('region', { name: 'Рекомендація' })).toHaveTextContent('Направити засіб для перевірки');
    expect(screen.getByLabelText(/Направити засіб для перевірки/)).toBeChecked();
    await userEvent.click(screen.getByRole('button', { name: 'Ухвалити рішення' }));
    expect(screen.getByText(/Оберіть обґрунтування/)).toBeInTheDocument();
  });
  it('ухвалити рішення: запит у SENTINEL, черга зменшується, розбір', async () => {
    renderApp('/anomalies/rendezvous%3Atrk-6102%2Btrk-6103');
    await userEvent.selectOptions(await screen.findByLabelText('Обґрунтування'), 'score');
    await userEvent.click(screen.getByRole('button', { name: 'Ухвалити рішення' }));
    const dec = await screen.findByRole('region', { name: 'Ухвалене рішення' });
    expect(dec).toHaveTextContent('req-0041');
    expect(screen.getByRole('link', { name: 'Потребують рішення: 5' })).toBeInTheDocument();
    await userEvent.click(within(dec).getByRole('button', { name: 'Не підтвердилося' }));
    expect(dec).toHaveTextContent('Не підтвердилося');
  });
  it('рішення не за рекомендацією позначається', async () => {
    renderApp('/anomalies/jump%3Atrk-6105');
    await userEvent.click(await screen.findByLabelText(/Визнати нормою/));
    await userEvent.selectOptions(screen.getByLabelText('Обґрунтування'), 'sensor_error');
    await userEvent.click(screen.getByRole('button', { name: 'Ухвалити рішення' }));
    expect(await screen.findByRole('region', { name: 'Ухвалене рішення' })).toHaveTextContent('не за рекомендацією');
  });
  it('спостерігати: вимагає строку, з\'являється на «Спостереженні», після строку — знову на рішення', async () => {
    let now = Date.parse('2026-11-14T11:00:00Z');
    const { store } = renderApp('/anomalies/loiter%3Atrk-6107', { clock: () => now });
    await userEvent.click(await screen.findByLabelText(/^Спостерігати/));
    await userEvent.selectOptions(screen.getByLabelText('Обґрунтування'), 'score');
    await userEvent.click(screen.getByRole('button', { name: 'Ухвалити рішення' }));
    expect(screen.getByText('Оберіть, скільки спостерігати.')).toBeInTheDocument();
    await userEvent.selectOptions(screen.getByLabelText('Скільки спостерігати'), '30');
    await userEvent.click(screen.getByRole('button', { name: 'Ухвалити рішення' }));
    await userEvent.click(await screen.findByRole('link', { name: /Спостереження/ }));
    expect(screen.getByRole('list', { name: 'Тривають' })).toHaveTextContent('лишилось 30 хв');
    now += 31 * 60000;
    act(() => store.setState({ updatedAt: now }));
    expect(screen.getByRole('list', { name: 'Завершені спостереження' })).toHaveTextContent('Ухвалити рішення');
  });
  it('аномалії немає в обстановці', async () => {
    renderApp('/anomalies/loiter%3Atrk-9999');
    expect(await screen.findByText('Цієї аномалії зараз немає в обстановці')).toBeInTheDocument();
  });
});

describe('Журнал рішень', () => {
  it('порожній на початку', async () => {
    renderApp('/decisions');
    expect(await screen.findByText('Журнал рішень порожній')).toBeInTheDocument();
  });
  it('рішення, розбір у таблиці, статистика за типами, фільтр', async () => {
    const { store } = renderApp('/decisions');
    await screen.findByText('Журнал рішень порожній');
    await act(() => store.getState().decide('jump:trk-6105', { action: 'contact', reason: 'score', recommended: 'contact' }));
    await act(() => store.getState().decide('dark:trk-6104', { action: 'verify', reason: 'score', recommended: 'verify' }));
    const t = screen.getByRole('table', { name: 'Журнал рішень' });
    await userEvent.click(within(t).getAllByRole('button', { name: 'Ні' })[0]);
    expect(screen.getByRole('table', { name: 'Статистика за типами' })).toHaveTextContent('Вимкнення AIS111100%');
    await userEvent.selectOptions(screen.getByLabelText('Розбір'), 'pending');
    expect(within(t).getAllByRole('row').filter((r) => r.hasAttribute('data-row'))).toHaveLength(1);
  });
});
