import { describe, expect, it, vi } from 'vitest';
import { createMockSource, createRestSource } from '../src/data/source.js';
import { createAppStore } from '../src/store/store.js';
import { memoryStorage, T0 } from './helpers.jsx';

const make = (o = {}) => createAppStore(o.source ?? createMockSource({ latency: 0, interval: 60000, now: () => T0, ...o }), { now: () => T0, storage: o.storage ?? memoryStorage() });

describe('сховище', () => {
  it('старт: райони, історія, аномалії', async () => {
    const s = make();
    await s.getState().start();
    expect(s.getState().status).toBe('ready');
    expect(s.getState().histories).toHaveLength(11);
    expect(s.getState().anomalies).toHaveLength(6);
    s.getState().stop();
  });
  it('помилка першого завантаження', async () => {
    const s = make({ scenario: 'error' });
    await s.getState().start();
    expect(s.getState()).toMatchObject({ status: 'error', error: { status: 503 } });
  });
  it('перевірка засобом записує запит у SENTINEL і посилання в рішенні', async () => {
    const s = make();
    await s.getState().start();
    const r = await s.getState().decide('rendezvous:trk-6102+trk-6103', { action: 'verify', reason: 'score', recommended: 'verify' });
    expect(r.decision).toMatchObject({ action: 'verify', ref: 'req-0041', followed: true });
    expect(s.getState().archive).toHaveLength(1);
    s.getState().stop();
  });
  it('якщо запис у SENTINEL не пройшов — рішення не записується', async () => {
    const source = { ...createMockSource({ latency: 0, interval: 60000, now: () => T0 }), escalate: () => Promise.reject(new Error('503')) };
    const s = make({ source });
    await s.getState().start();
    const r = await s.getState().decide('air_circle:trk-7101', { action: 'escalate', reason: 'score', recommended: 'escalate' });
    expect(r).toMatchObject({ ok: false });
    expect(s.getState().archive).toHaveLength(0);
    s.getState().stop();
  });
  it('розбір рішення оновлює і архів, і поточне рішення; усе переживає перезавантаження', async () => {
    const storage = memoryStorage();
    const s = make({ storage });
    await s.getState().start();
    const { decision } = await s.getState().decide('jump:trk-6105', { action: 'contact', reason: 'score', recommended: 'contact' });
    s.getState().review(decision.id, 'refuted');
    expect(s.getState().decisions['jump:trk-6105'].review).toBe('refuted');
    s.getState().stop();
    const again = make({ storage });
    expect(again.getState().archive[0]).toMatchObject({ review: 'refuted' });
  });
});

describe('джерело даних', () => {
  it('сценарій stale: після двох оновлень — помилка', () => {
    vi.useFakeTimers();
    const ok = vi.fn(), fail = vi.fn();
    const stop = createMockSource({ scenario: 'stale', interval: 100 }).subscribe({ onHistory: ok, onError: fail });
    vi.advanceTimersByTime(350); stop(); vi.useRealTimers();
    expect([ok.mock.calls.length, fail.mock.calls.length]).toEqual([2, 1]);
  });
  it('адаптер REST: історія для кожного треку, запит на перевірку', async () => {
    const fetchImpl = vi.fn((url) => Promise.resolve({ ok: true, json: () => Promise.resolve(url.endsWith('/v1/tracks') ? [{ id: 'trk-1' }] : url.includes('history') ? { items: [{ ts: 'x' }] } : { id: 'req-1' }) }));
    const s = createRestSource({ baseUrl: 'https://api', token: 't', fetchImpl });
    expect(await s.loadHistory()).toEqual([{ id: 'trk-1', points: [{ ts: 'x' }] }]);
    await s.requestCheck({ track_ids: ['trk-1'] });
    expect(fetchImpl.mock.calls.map(([u, o]) => `${o.method} ${u}`)).toEqual([
      'GET https://api/v1/tracks', 'GET https://api/v1/tracks/trk-1/history?minutes=40', 'POST https://api/v1/collection-requests',
    ]);
  });
  it('помилка HTTP', async () => {
    const s = createRestSource({ baseUrl: 'https://api', fetchImpl: () => Promise.resolve({ ok: false, status: 502 }) });
    await expect(s.loadAreas()).rejects.toMatchObject({ status: 502 });
  });
});
