import { render } from '@testing-library/react';
import { useEffect } from 'react';
import { MemoryRouter, useLocation } from 'react-router';
import { App } from '../src/App.jsx';
import { createMockSource } from '../src/data/source.js';
import { createAppStore } from '../src/store/store.js';

export const T0 = Date.parse('2026-11-14T11:00:00Z');

export function memoryStorage(init = {}) {
  const data = { ...init };
  return { data, getItem: (k) => (k in data ? data[k] : null), setItem: (k, v) => { data[k] = String(v); } };
}

const probe = { current: null };
function LocationProbe() {
  const loc = useLocation();
  useEffect(() => { probe.current = loc; }, [loc]);
  return null;
}
export const location = () => probe.current;

export function renderApp(path = '/anomalies', { scenario = 'normal', clock = () => T0, storage = memoryStorage(), interval = 60000 } = {}) {
  const source = createMockSource({ scenario, latency: 0, interval, now: clock });
  const store = createAppStore(source, { now: clock, storage });
  const utils = render(<MemoryRouter initialEntries={[path]}><App createStore={() => store} /><LocationProbe /></MemoryRouter>);
  return { store, source, storage, ...utils };
}
