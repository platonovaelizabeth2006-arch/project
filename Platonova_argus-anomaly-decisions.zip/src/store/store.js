import { createStore } from 'zustand/vanilla';
import { CLASS_MAX_KN } from '../data/world.js';
import { detectAll } from '../domain/anomalies.js';
import { makeDecision } from '../domain/decisions.js';

const KEY = 'argus.anomaly.v1';
function read(st) { try { const r = st?.getItem(KEY); return r ? JSON.parse(r) : null; } catch { return null; } }
function write(st, d) { try { st?.setItem(KEY, JSON.stringify(d)); } catch { /* рішення не переживуть перезавантаження */ } }

// Стан: історія треків і райони з SENTINEL, виявлені аномалії, рішення оператора (з переглядом) і журнал рішень.
// Аномалії переобчислюються з кожним оновленням історії — так і без відкритого екрана видно, що ознаки посилились.
export function createAppStore(source, { now = () => Date.now(), storage = globalThis.localStorage } = {}) {
  const saved = read(storage);
  let unsubscribe = null;

  return createStore((set, get) => {
    const save = () => write(storage, { decisions: get().decisions, archive: get().archive });
    const apply = (histories) => set({ histories, anomalies: detectAll(histories, get().areas, CLASS_MAX_KN), updatedAt: now(), stale: null });

    return {
      status: 'loading', error: null, stale: null, updatedAt: null,
      areas: [], histories: [], anomalies: [],
      decisions: saved?.decisions ?? {},     // останнє рішення за id аномалії
      archive: saved?.archive ?? [],         // усі рішення, нові зверху: для журналу і статистики

      async start() {
        get().stop();
        set({ status: 'loading', error: null, stale: null });
        try {
          const [areas, histories] = await Promise.all([source.loadAreas(), source.loadHistory()]);
          set({ areas, status: 'ready' });
          apply(histories);
          unsubscribe = source.subscribe({ onHistory: apply, onError: (e) => set({ stale: { message: e.message, status: e.status ?? null } }) });
        } catch (e) {
          set({ status: 'error', error: { message: e.message, status: e.status ?? null } });
        }
      },
      stop() { unsubscribe?.(); unsubscribe = null; },

      // Ухвалити рішення. Для перевірки і доповіді спершу пишемо в SENTINEL; якщо не вдалося — рішення не записуємо,
      // щоб журнал не стверджував того, чого не сталося.
      async decide(anomalyId, d) {
        const a = get().anomalies.find((x) => x.id === anomalyId);
        if (!a) return { ok: false, error: 'аномалії вже немає в обстановці' };
        let ref = null;
        try {
          if (d.action === 'verify') ref = (await source.requestCheck({ track_ids: a.trackIds, reason: a.type, priority: a.level })).id;
          if (d.action === 'escalate') ref = (await source.escalate({ type: 'anomaly', severity: 'high', track_ids: a.trackIds, note: d.note })).id;
        } catch (e) {
          return { ok: false, error: `запис у SENTINEL не пройшов: ${e.message}` };
        }
        const dec = { ...makeDecision(a, d, now()), ref, id: `dec-${now().toString(36)}-${get().archive.length}` };
        set({ decisions: { ...get().decisions, [anomalyId]: dec }, archive: [dec, ...get().archive] });
        save();
        return { ok: true, decision: dec };
      },

      // Розбір: чи підтвердилося рішення. Позначка йде і в архів, і в поточне рішення.
      review(decisionId, review) {
        const archive = get().archive.map((d) => (d.id === decisionId ? { ...d, review, reviewedAt: now() } : d));
        const changed = archive.find((d) => d.id === decisionId);
        const decisions = { ...get().decisions };
        if (changed && decisions[changed.anomalyId]?.id === decisionId) decisions[changed.anomalyId] = changed;
        set({ archive, decisions });
        save();
      },
    };
  });
}
