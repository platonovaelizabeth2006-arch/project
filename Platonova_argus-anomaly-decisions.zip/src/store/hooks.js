import { createContext, useContext, useMemo } from 'react';
import { useStore } from 'zustand';
import { needsDecision, recommend, stats, statusOf } from '../domain/decisions.js';

export const StoreContext = createContext(null);

export function useApp(selector) {
  const store = useContext(StoreContext);
  if (!store) throw new Error('useApp поза StoreContext');
  return useStore(store, selector);
}

export function useActions() {
  const store = useContext(StoreContext);
  return useMemo(() => { const s = store.getState(); return { start: s.start, stop: s.stop, decide: s.decide, review: s.review }; }, [store]);
}

export function useLoadState() {
  const status = useApp((s) => s.status);
  const error = useApp((s) => s.error);
  const stale = useApp((s) => s.stale);
  const updatedAt = useApp((s) => s.updatedAt);
  return { status, error, stale, updatedAt };
}

// Аномалії зі станом, рекомендацією і назвами об'єктів. «Зараз» — момент оновлення.
export function useAnomalies() {
  const anomalies = useApp((s) => s.anomalies);
  const decisions = useApp((s) => s.decisions);
  const histories = useApp((s) => s.histories);
  const updatedAt = useApp((s) => s.updatedAt);
  return useMemo(() => {
    const byId = Object.fromEntries(histories.map((h) => [h.id, h]));
    return anomalies.map((a) => {
      const tracks = a.trackIds.map((id) => byId[id]).filter(Boolean);
      const decision = decisions[a.id] ?? null;
      const status = statusOf(a, decision, updatedAt ?? 0);
      return {
        ...a, tracks, decision, status, needs: needsDecision(status),
        title: tracks.map((t) => t.name ?? t.id).join(' + '),
        rec: recommend(a, { hasAis: tracks.some((t) => t.source !== 'radar') }),
      };
    }).sort((x, y) => (y.needs - x.needs) || y.score - x.score);
  }, [anomalies, decisions, histories, updatedAt]);
}

export function useCounts() {
  const list = useAnomalies();
  const archive = useApp((s) => s.archive);
  const updatedAt = useApp((s) => s.updatedAt);
  return useMemo(() => ({
    needs: list.filter((a) => a.needs).length,
    needsHigh: list.filter((a) => a.needs && a.level === 'high').length,
    watch: archive.filter((d) => d.action === 'watch' && d.until > (updatedAt ?? 0)).length,
    unreviewed: archive.filter((d) => !d.review).length,
  }), [list, archive, updatedAt]);
}

export function useStats() {
  const archive = useApp((s) => s.archive);
  return useMemo(() => stats(archive), [archive]);
}
