import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter } from 'react-router';
import '@fontsource/ibm-plex-sans/400.css';
import '@fontsource/ibm-plex-sans/600.css';
import '@fontsource/ibm-plex-mono/400.css';
import './styles/tokens.css';
import './styles/app.css';
import { App } from './App.jsx';
import { sourceFromEnvironment } from './data/source.js';
import { createAppStore } from './store/store.js';

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <BrowserRouter>
      <App createStore={() => createAppStore(sourceFromEnvironment())} />
    </BrowserRouter>
  </StrictMode>,
);
