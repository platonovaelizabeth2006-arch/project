import { useEffect, useState } from 'react';
import { Navigate, Route, Routes } from 'react-router';
import { AnomaliesView } from './anomalies/AnomaliesView.jsx';
import { AnomalyView } from './anomalies/AnomalyView.jsx';
import { DecisionsView } from './decisions/DecisionsView.jsx';
import { Shell } from './shell/Shell.jsx';
import { StoreContext } from './store/hooks.js';
import { WatchView } from './watch/WatchView.jsx';

// Маршрути підсистеми підтримки рішень щодо аномалій:
//   /anomalies?show&a          черга аномалій і карта слідів
//   /anomalies/:anomalyId      картка рішення: ознаки, рух, рекомендація, варіанти, рішення, розбір
//   /watch                     об'єкти на спостереженні
//   /decisions?review          журнал рішень і статистика розбору
export function AppRoutes() {
  return (
    <Routes>
      <Route element={<Shell />}>
        <Route index element={<Navigate to="/anomalies" replace />} />
        <Route path="anomalies" element={<AnomaliesView />} />
        <Route path="anomalies/:anomalyId" element={<AnomalyView />} />
        <Route path="watch" element={<WatchView />} />
        <Route path="decisions" element={<DecisionsView />} />
        <Route path="*" element={<Navigate to="/anomalies" replace />} />
      </Route>
    </Routes>
  );
}

export function App({ createStore }) {
  const [store] = useState(createStore);
  useEffect(() => { store.getState().start(); return () => store.getState().stop(); }, [store]);
  return <StoreContext.Provider value={store}><AppRoutes /></StoreContext.Provider>;
}
