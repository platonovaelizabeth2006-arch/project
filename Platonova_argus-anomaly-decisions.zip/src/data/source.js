import { AREAS, historyAt } from './world.js';

// Джерело даних. Сховище не знає, звідки дані — імітатор чи SENTINEL:
//   loadAreas()                      -> Promise<Area[]>     райони, що змінюють оцінку
//   loadHistory()                    -> Promise<History[]>  треки з історією за 40 хв
//   subscribe({ onHistory, onError }) -> unsubscribe       оновлення кожні ~5 с
//   requestCheck(body)               -> Promise<{ id }>     запит на перевірку засобом
//   escalate(body)                   -> Promise<{ id }>     доповідь старшому (подія)
export const SCENARIOS = ['normal', 'slow', 'loading', 'empty', 'error', 'stale'];
const wait = (ms) => new Promise((r) => setTimeout(r, ms));

export class SourceError extends Error {
  constructor(message, status) { super(message); this.status = status; }
}

// Імітатор. loading — відповіді немає; error — 503; empty — у районі немає треків; stale — після двох оновлень обрив; slow — 4 с.
export function createMockSource({ scenario = 'normal', latency = 400, interval = 5000, now = () => Date.now() } = {}) {
  const t0 = now();
  const delay = scenario === 'slow' ? 4000 : latency;
  let ticks = 0, seq = 41;
  const history = () => (scenario === 'empty' ? [] : historyAt(now(), t0));
  async function answer(v) {
    if (scenario === 'loading') return new Promise(() => {});
    await wait(delay);
    if (scenario === 'error') throw new SourceError('Сервіс SENTINEL не відповів', 503);
    return v;
  }
  return {
    loadAreas: () => answer(structuredClone(AREAS)),
    loadHistory: () => answer(history()),
    subscribe({ onHistory, onError }) {
      const id = setInterval(() => {
        ticks += 1;
        if (scenario === 'stale' && ticks > 2) onError(new SourceError('Потік оновлень перервано', 503));
        else onHistory(history());
      }, interval);
      return () => clearInterval(id);
    },
    requestCheck: async () => ({ id: `req-${String(seq++).padStart(4, '0')}` }),
    escalate: async () => ({ id: `evt-${String(3000 + seq++)}` }),
  };
}

// Справжній SENTINEL. Історію беремо з /v1/tracks/{id}/history для кожного треку в районі.
export function createRestSource({ baseUrl, token, interval = 5000, fetchImpl = fetch }) {
  const headers = { Accept: 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) };
  const list = (b) => (Array.isArray(b) ? b : b.items ?? []);
  async function req(path, { method = 'GET', body } = {}) {
    const res = await fetchImpl(`${baseUrl}${path}`, { method, headers: body ? { ...headers, 'Content-Type': 'application/json' } : headers, body: body ? JSON.stringify(body) : undefined });
    if (!res.ok) throw new SourceError(`${method} ${path} → ${res.status}`, res.status);
    return res.json();
  }
  async function history() {
    const tracks = list(await req('/v1/tracks'));
    const h = await Promise.all(tracks.map((t) => req(`/v1/tracks/${t.id}/history?minutes=40`)));
    return tracks.map((t, i) => ({ ...t, points: list(h[i]) }));
  }
  return {
    loadAreas: async () => list(await req('/v1/zones')),
    loadHistory: history,
    subscribe({ onHistory, onError }) {
      let alive = true;
      const id = setInterval(() => history().then((h) => alive && onHistory(h), (e) => alive && onError(e)), interval);
      return () => { alive = false; clearInterval(id); };
    },
    requestCheck: (body) => req('/v1/collection-requests', { method: 'POST', body }),
    escalate: (body) => req('/v1/events', { method: 'POST', body }),
  };
}

export function sourceFromEnvironment(search = globalThis.location?.search ?? '') {
  const apiUrl = import.meta.env?.VITE_API_URL;
  if (apiUrl) return createRestSource({ baseUrl: apiUrl, token: import.meta.env?.VITE_API_TOKEN });
  const sim = new URLSearchParams(search).get('sim');
  return createMockSource({ scenario: SCENARIOS.includes(sim) ? sim : 'normal' });
}
