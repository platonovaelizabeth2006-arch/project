import { fromLocalNm } from '../domain/geo.js';

// Синтетичний район 46 × 34 милі: суходіл на заході з портом, на сході море, рибальський район і трубопровід.
// Рух кожного об'єкта задано сценарієм — відрізками від t0 − 40 хв; так в історії треку є саме ті аномалії,
// які треба показати, і вони відтворюються однаково на кожному запуску. Нічого справжнього.
export const ORIGIN = [31.4, 45.95];
const at = (p) => fromLocalNm(p, ORIGIN).map((v) => +v.toFixed(5));
const ll = (pts) => pts.map(at);

export const AREA_NM = { minX: 0, minY: 0, maxX: 46, maxY: 34 };
export const LAND = ll([[-30, -30], [6, -30], [7.5, 5], [10, 9], [8.6, 14], [11, 18], [8.8, 23], [7, 30], [5, 70], [-30, 70]]);

// Райони, що змінюють оцінку: у порту і на якірній стоянці зупинка — норма, у рибальському районі кружляння — норма,
// біля трубопроводу і в секторі аеродрому — навпаки, підозра вища.
export const AREAS = [
  { id: 'zon-port', name: 'Порт і внутрішній рейд', kind: 'port', effect: 'normal_stop', polygon: ll([[8, 10], [14, 10], [14, 16], [8, 16]]) },
  { id: 'zon-anch', name: 'Якірна стоянка № 2', kind: 'anchorage', effect: 'normal_stop', polygon: ll([[16, 20], [21, 20], [21, 24], [16, 24]]) },
  { id: 'zon-fish', name: 'Рибальський район «Банка»', kind: 'fishing', effect: 'normal_loiter', polygon: ll([[30, 4], [40, 4], [40, 12], [30, 12]]) },
  { id: 'zon-pipe', name: 'Підводний трубопровід', kind: 'critical', effect: 'raise', polygon: ll([[14, 26.6], [44, 26.6], [44, 28.4], [14, 28.4]]) },
  { id: 'zon-air', name: 'Сектор захоплення аеродрому', kind: 'approach', effect: 'normal_low', polygon: ll([[2, 2], [16, 0], [16, 7], [2, 6]]) },
];

// Типова максимальна швидкість за класом — з неї видно, що «рибальське» на 25 вузлах щось приховує.
export const CLASS_MAX_KN = { fishing: 14, cargo: 20, tanker: 17, pilot: 30, passenger: 28, unknown: 40 };

// Сценарій: [тривалість хв, з [x,y], до [x,y], ознаки]. ais: false — AIS мовчить, трек веде лише РЛС або ніхто.
// jump — у цьому відрізку координати хибні (стрибок) — так виглядає підміна AIS.
const S = (min, from, to, o = {}) => ({ min, from, to, ...o });
const TRACKS = [
  { id: 'trk-6101', name: 'OCEAN PRIDE', domain: 'sea', kind: 'tanker', cls: 'neutral', src: 'both', script: [
    S(15, [37, 28.6], [33, 27.6]),
    S(25, [33, 27.6], [33.3, 27.4], { circle: 0.25 }),       // повільно кружляє над трубопроводом
    S(20, [33.3, 27.4], [33.1, 27.5], { circle: 0.25 }),
  ] },
  { id: 'trk-6102', name: 'KAPITAN R', domain: 'sea', kind: 'cargo', cls: 'neutral', src: 'both', script: [
    S(18, [32, 17.4], [27, 18]),
    S(42, [27, 18], [27.05, 18.02]),                         // стоїть у відкритому морі
  ] },
  { id: 'trk-6103', name: null, domain: 'sea', kind: 'unknown', cls: 'unknown', src: 'radar', script: [
    S(22, [26, 26], [27.15, 18.1]),
    S(38, [27.15, 18.1], [27.15, 18.1]),                     // підійшов і стоїть борт до борту
  ] },
  { id: 'trk-6104', name: 'SILVER FISH', domain: 'sea', kind: 'fishing', cls: 'neutral', src: 'ais', script: [
    S(12, [36, 8], [37, 9]),
    S(14, [37, 9], [33.2, 12.4], { ais: false }),            // AIS вимкнено: за 14 хв — 5 миль, ~22 вуз
    S(34, [33.2, 12.4], [34.6, 13.6]),
  ] },
  { id: 'trk-6105', name: 'BALTIC WAVE', domain: 'sea', kind: 'cargo', cls: 'neutral', src: 'ais', script: [
    S(32, [39.5, 7.5], [30, 12]),
    S(1, [30, 12], [12, 30], { jump: true }),                // стрибок на 25 миль за хвилину і назад
    S(27, [30.3, 12.2], [24, 15]),
  ] },
  { id: 'trk-6106', name: 'NORD STAR', domain: 'sea', kind: 'cargo', cls: 'neutral', src: 'both', script: [
    S(60, [45, 22], [29, 17.4]),
  ] },
  { id: 'trk-6107', name: 'ЧАЙКА-4', domain: 'sea', kind: 'fishing', cls: 'neutral', src: 'ais', script: [
    S(60, [34, 7], [34.2, 7.1], { circle: 0.3 }),            // кружляє — але в рибальському районі
  ] },
  { id: 'trk-6108', name: 'ЛОЦМАН-3', domain: 'sea', kind: 'pilot', cls: 'friendly', src: 'both', script: [
    S(30, [12, 13], [22, 21]), S(30, [22, 21], [12, 13]),
  ] },
  { id: 'trk-7101', name: 'UR-LKT', domain: 'air', kind: 'light', cls: 'unknown', src: 'adsb', alt: 800, script: [
    S(20, [40, 34], [18, 20], { alt: 3500 }),
    S(40, [18, 20], [18.2, 20.1], { circle: 1.2, period: 4, alt: 800 }), // кружляє на 800 футах над якірною стоянкою
  ] },
  { id: 'trk-7102', name: 'WZZ2851', domain: 'air', kind: 'airliner', cls: 'neutral', src: 'adsb', script: [
    S(60, [-10, 34], [60, 0], { alt: 34000 }),
  ] },
  { id: 'trk-7103', name: 'URHEL5', domain: 'air', kind: 'helicopter', cls: 'neutral', src: 'adsb', script: [
    S(30, [30, 2], [8, 4], { alt: 1200 }), S(30, [8, 4], [8, 4], { alt: 600 }),  // низько, але в секторі аеродрому
  ] },
];
export const TRACK_IDS = TRACKS.map((t) => t.id);
export const HISTORY_MIN = 40;    // на скільки хвилин назад зберігається історія
export const SAMPLE_S = 30;       // крок історії

function circleStart(track) {
  let t = 0;
  for (const s of track.script) { if (s.circle) return t; t += s.min; }
  return 0;
}

function pointAt(track, minute) {
  const total = Math.max(0, minute);
  let m = total;
  for (const s of track.script) {
    if (m <= s.min || s === track.script[track.script.length - 1]) {
      const k = Math.min(1, m / s.min);
      let x = s.from[0] + (s.to[0] - s.from[0]) * k;
      let y = s.from[1] + (s.to[1] - s.from[1]) * k;
      if (s.circle) {
        // коло починається з поточної точки (зсув 0), фаза — від початку першого відрізка з колом:
        // так немає стрибка ні на вході в кружляння, ні між двома відрізками з колом
        const start = circleStart(track);
        const a = ((total - start) / (s.period ?? 15)) * 2 * Math.PI;
        x += s.circle * (Math.cos(a) - 1); y += s.circle * Math.sin(a);
      }
      return { x, y, seg: s, mInSeg: m };
    }
    m -= s.min;
  }
  return null;
}

// Стан об'єкта на хвилині сценарію (0 = t0 − 40 хв). Курс і швидкість — з положення через 30 с.
function stateAt(track, minute) {
  const p = pointAt(track, minute);
  const q = pointAt(track, minute + 0.5);
  const dx = q.x - p.x, dy = q.y - p.y;
  const sog = p.seg.jump ? 0 : Math.round((Math.hypot(dx, dy) / (0.5 / 60)) * 10) / 10;
  const cog = Math.round(((Math.atan2(dx, dy) * 180) / Math.PI + 360) % 360);
  const [lon, lat] = fromLocalNm([p.x, p.y], ORIGIN);
  return { lon: +lon.toFixed(5), lat: +lat.toFixed(5), sog, cog, ais: p.seg.ais !== false, alt: p.seg.alt ?? track.alt };
}

const meta = (t) => ({ id: t.id, name: t.name, domain: t.domain, kind: t.kind, classification: t.cls, source: t.src });

// Історія треку за останні HISTORY_MIN хвилин до now, крок SAMPLE_S.
// Точки, у яких AIS мовчав, а РЛС цей трек не веде, в історію не потрапляють — це і є «дірка».
export function historyAt(now, t0 = now) {
  const nowMin = HISTORY_MIN + (now - t0) / 60000;
  return TRACKS.map((t) => {
    const points = [];
    for (let m = Math.max(0, nowMin - HISTORY_MIN); m <= nowMin + 1e-9; m += SAMPLE_S / 60) {
      const s = stateAt(t, m);
      const silent = !s.ais && t.src === 'ais';
      if (silent) continue;
      points.push({ ts: new Date(t0 + (m - HISTORY_MIN) * 60000).toISOString(), lon: s.lon, lat: s.lat, sog: s.sog, cog: s.cog, ...(t.domain === 'air' ? { alt: s.alt } : {}) });
    }
    return { ...meta(t), points };
  });
}

// Поточні треки — останні точки історії.
export function snapshot(now, t0 = now) {
  return historyAt(now, t0).map(({ points, ...t }) => ({ ...t, ...points[points.length - 1] }));
}
