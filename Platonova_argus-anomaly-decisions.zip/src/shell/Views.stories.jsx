import { useEffect, useState } from 'react';
import { MemoryRouter } from 'react-router';
import { AppRoutes } from '../App.jsx';
import { createMockSource } from '../data/source.js';
import { StoreContext } from '../store/hooks.js';
import { createAppStore } from '../store/store.js';

export default { title: 'Views' };

function Live({ path, scenario, after, height = '100vh' }) {
  const [store] = useState(() => createAppStore(createMockSource({ scenario, latency: 300 }), { storage: null }));
  useEffect(() => { store.getState().start().then(() => after?.(store.getState())); return () => store.getState().stop(); }, [store, after]);
  return <div style={{ height, margin: -24 }}><StoreContext.Provider value={store}><MemoryRouter initialEntries={[path]}><AppRoutes /></MemoryRouter></StoreContext.Provider></div>;
}

const decideSome = async (s) => {
  await s.decide('rendezvous:trk-6102+trk-6103', { action: 'verify', reason: 'score', recommended: 'verify' });
  const j = await s.decide('jump:trk-6105', { action: 'dismiss', reason: 'sensor_error', note: 'збій GNSS у районі, підтверджено СУРС', recommended: 'contact' });
  await s.decide('loiter:trk-6107', { action: 'watch', reason: 'score', minutes: 30, recommended: 'watch' });
  const d = await s.decide('dark:trk-6104', { action: 'verify', reason: 'context', recommended: 'verify' });
  s.review(j.decision.id, 'confirmed'); s.review(d.decision.id, 'refuted');
};

export const AnomaliesData = () => <Live path="/anomalies?a=rendezvous%3Atrk-6102%2Btrk-6103" scenario="normal" />;
export const AnomaliesLoading = () => <Live path="/anomalies" scenario="loading" />;
export const AnomaliesEmpty = () => <Live path="/anomalies" scenario="empty" />;
export const AnomaliesError = () => <Live path="/anomalies" scenario="error" />;
export const AnomaliesStale = () => <Live path="/anomalies" scenario="stale" />;
export const AnomaliesAllDecided = () => <Live path="/anomalies" scenario="normal" after={decideSome} />;
export const DecisionCard = () => <Live path="/anomalies/loiter%3Atrk-6101" scenario="normal" />;
export const DecisionCardAir = () => <Live path="/anomalies/air_circle%3Atrk-7101" scenario="normal" />;
export const DecisionMade = () => <Live path="/anomalies/rendezvous%3Atrk-6102%2Btrk-6103" scenario="normal" after={decideSome} />;
export const DecisionLoading = () => <Live path="/anomalies/loiter%3Atrk-6101" scenario="loading" />;
export const DecisionNotFound = () => <Live path="/anomalies/loiter%3Atrk-9999" scenario="normal" />;
export const WatchEmpty = () => <Live path="/watch" scenario="normal" />;
export const WatchActive = () => <Live path="/watch" scenario="normal" after={decideSome} />;
export const DecisionsEmpty = () => <Live path="/decisions" scenario="normal" />;
export const DecisionsReviewed = () => <Live path="/decisions" scenario="normal" after={decideSome} />;
