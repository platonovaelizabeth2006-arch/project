import { useEffect } from 'react';
import { NavLink, Outlet, useLocation } from 'react-router';
import { useCounts } from '../store/hooks.js';
import { Icon } from '../ui/Icon.jsx';

const NAV = [
  { to: '/anomalies', label: 'Аномалії руху', short: 'Аномалії', icon: 'radar', count: 'needs' },
  { to: '/watch', label: 'Спостереження', short: 'Спостер.', icon: 'zones', count: 'watch' },
  { to: '/decisions', label: 'Журнал рішень', short: 'Рішення', icon: 'journal', count: 'unreviewed' },
];

export function Shell() {
  const counts = useCounts();
  const { pathname } = useLocation();
  useEffect(() => { document.title = counts.needs ? `(${counts.needs}) ARGUS · Аномалії руху` : 'ARGUS · Аномалії руху'; }, [counts.needs]);
  return (
    <div className={`shell${pathname === '/anomalies' ? ' shell--map' : ''}`}>
      <a className="skip-link" href="#main">Перейти до вмісту</a>
      <header className="header">
        <span className="header__brand">ARGUS</span>
        <span className="header__context">SENTINEL · ПІДТРИМКА РІШЕНЬ · АНОМАЛІЇ РУХУ</span>
        <span className="header__end">
          {counts.needs > 0 && (
            <NavLink to="/anomalies?show=needs" className="header__alert" aria-label={`Потребують рішення: ${counts.needs}`}>
              <Icon name="warning" size={20} /><span className="mono">{counts.needs}</span>
              {counts.needsHigh > 0 && <span className="header__overdue">високих {counts.needsHigh}</span>}
            </NavLink>
          )}
        </span>
      </header>
      <nav className="nav" aria-label="Підсистема">
        <p className="nav__group">Аномалії руху</p>
        {NAV.map((n) => (
          <NavLink key={n.to} to={n.to} className="nav__item">
            <Icon name={n.icon} /><span className="nav__label">{n.label}</span><span className="nav__short">{n.short}</span>
            <span className="nav__count mono">{counts[n.count] || ''}</span>
          </NavLink>
        ))}
      </nav>
      <main id="main" className="main" tabIndex={-1}><Outlet /></main>
    </div>
  );
}
