import { useLoadState } from '../store/hooks.js';
import { InlineNotification } from '../ui/InlineNotification.jsx';
import { fmtTime } from '../ui/format.js';

// Помилка без даних і застарілі дані — різні речі, і черговий має розрізняти їх з першого погляду.
export function StatusNotice() {
  const { status, error, stale, updatedAt } = useLoadState();
  if (status === 'error') {
    return (
      <InlineNotification title="Не вдалося завантажити обстановку">
        SENTINEL не відповів{error?.status ? ` (${error.status})` : ''}. Аномалій на екрані немає не тому, що їх немає в районі, —
        даних не отримано. Натисніть «Спробувати ще»; якщо не допомагає — доповідайте старшому і переходьте на резервний пульт. Рішення, ухвалені раніше, збережено.
      </InlineNotification>
    );
  }
  if (stale) {
    return (
      <InlineNotification kind="warning" title="Оновлення обстановки припинилися">
        Положення треків — станом на {fmtTime(updatedAt)}. Історія треків не поповнюється, нові аномалії не виявляються. Рішення щодо наявних записуються.
      </InlineNotification>
    );
  }
  return null;
}

export const lastUpdated = (t) => (t ? `оновлено ${fmtTime(t)}` : '');
