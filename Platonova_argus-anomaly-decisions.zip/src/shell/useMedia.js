import { useSyncExternalStore } from 'react';

export const NARROW = '(max-width: 672px)';
export const MEDIUM = '(max-width: 1100px)';

export function useMedia(query) {
  return useSyncExternalStore(
    (cb) => {
      const m = globalThis.matchMedia?.(query);
      m?.addEventListener('change', cb);
      return () => m?.removeEventListener('change', cb);
    },
    () => globalThis.matchMedia?.(query).matches ?? false,
    () => false,
  );
}
