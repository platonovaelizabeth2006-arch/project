import { useId } from 'react';

// Поле завжди з підписом над ним, ніколи — підказка замість підпису.
export function Select({ label, value, onChange, options, error }) {
  const id = useId();
  return (
    <div className={`field${error ? ' has-error' : ''}`}>
      <label className="field__label" htmlFor={id}>{label}</label>
      <select id={id} className="field__control" value={value} onChange={(e) => onChange(e.target.value)}
        aria-invalid={error ? true : undefined} aria-describedby={error ? `${id}-e` : undefined}>
        {options.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
      </select>
      {error && <span id={`${id}-e`} className="field__error">{error}</span>}
    </div>
  );
}
