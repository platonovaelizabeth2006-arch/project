import { STATUS_LABEL, STATUS_TAG } from '../domain/decisions.js';

export const statusTag = (a) => ({ tag: STATUS_TAG[a.status], label: STATUS_LABEL[a.status] });
export const REVIEW = { confirmed: { label: 'Підтвердилося', tag: 'green' }, refuted: { label: 'Не підтвердилося', tag: 'red' } };
export const KIND_LABEL = {
  tanker: 'танкер', cargo: 'суховантаж', fishing: 'рибальське', pilot: 'лоцманський катер', unknown: 'невідомий тип',
  light: 'легкомоторний літак', airliner: 'пасажирський літак', helicopter: 'вертоліт',
};
export const CLASS_LABEL = { friendly: 'свій', neutral: 'нейтральний', unknown: 'невідомий', suspect: 'підозрілий' };
export const SOURCE_LABEL = { ais: 'AIS', both: 'AIS і РЛС', radar: 'лише РЛС', adsb: 'ADS-B' };
export const mins = (ms) => {
  const m = Math.max(0, Math.round(ms / 60000));
  return m < 60 ? `${m} хв` : `${Math.floor(m / 60)} год ${String(m % 60).padStart(2, '0')} хв`;
};
