import { useRef } from 'react';
import { SkeletonBar } from './Skeleton.jsx';

// Таблиця даних ARGUS: заголовок 40, рядки 48, футер «скільки з скількох».
// На вузькому екрані (≤ 672 px) рядки стають картками — це робить CSS за data-label;
// колонки з narrow: false на картці не показуються, aside: true — у правому верхньому куті картки.
//
// Клавіатура: Tab заходить у таблицю на вибраний рядок, ↑/↓ — між рядками,
// Enter — відкрити, пробіл — вибрати.
export function DataTable({
  label, columns, rows, getKey, selectedKey, onSelect, onOpen,
  loading = false, stale = false, empty = null, footer, edgeOf,
}) {
  const bodyRef = useRef(null);

  function focusRow(index) {
    const rowsEls = bodyRef.current?.querySelectorAll('tr[data-row]');
    if (!rowsEls?.length) return;
    const i = Math.max(0, Math.min(rowsEls.length - 1, index));
    rowsEls[i].focus();
  }

  function onKeyDown(e, row, index) {
    if (e.target !== e.currentTarget) return; // клавіші всередині кнопки рядка — її справа
    if (e.key === 'ArrowDown') { e.preventDefault(); focusRow(index + 1); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); focusRow(index - 1); }
    else if (e.key === 'Home') { e.preventDefault(); focusRow(0); }
    else if (e.key === 'End') { e.preventDefault(); focusRow(rows.length - 1); }
    else if (e.key === 'Enter' && onOpen) { e.preventDefault(); onOpen(row); }
    else if (e.key === ' ' && onSelect) { e.preventDefault(); onSelect(row); }
  }

  const hasSelection = rows.some((r) => getKey(r) === selectedKey);

  return (
    <div className={`table-wrap${stale ? ' is-stale' : ''}`}>
      <table className="table" aria-label={label} aria-busy={loading || undefined}>
        <thead>
          <tr>
            {columns.map((c) => (
              <th key={c.key} scope="col" aria-sort={c.ariaSort} className={c.align === 'end' ? 'num' : undefined} style={c.width ? { width: c.width } : undefined}>
                {c.header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody ref={bodyRef}>
          {loading && Array.from({ length: 5 }, (_, i) => (
            <tr key={`sk-${i}`} className="row-skeleton" aria-hidden="true">
              {columns.map((c, j) => <td key={c.key}><SkeletonBar width={j === 0 ? '70%' : '45%'} /></td>)}
            </tr>
          ))}
          {!loading && rows.length === 0 && (
            <tr className="row-empty"><td colSpan={columns.length}>{empty}</td></tr>
          )}
          {!loading && rows.map((row, index) => {
            const key = getKey(row);
            const selected = key === selectedKey;
            const edge = edgeOf?.(row);
            return (
              <tr
                key={key}
                data-row
                tabIndex={selected || (!hasSelection && index === 0) ? 0 : -1}
                aria-selected={onSelect ? selected : undefined}
                className={[selected && 'is-selected', edge && `edge--${edge}`].filter(Boolean).join(' ') || undefined}
                onClick={() => onSelect?.(row)}
                onDoubleClick={() => onOpen?.(row)}
                onKeyDown={(e) => onKeyDown(e, row, index)}
              >
                {columns.map((c) => (
                  <td key={c.key} data-label={c.label ?? c.header}
                    className={[c.align === 'end' && 'num', c.mono && 'mono', c.narrow === false && 'hide-narrow', c.aside && 'card-aside', c.labelled && 'card-labelled', c.className].filter(Boolean).join(' ') || undefined}>
                    {c.render ? c.render(row) : row[c.key]}
                  </td>
                ))}
              </tr>
            );
          })}
        </tbody>
      </table>
      {footer && <div className="table-footer">{footer}</div>}
    </div>
  );
}
