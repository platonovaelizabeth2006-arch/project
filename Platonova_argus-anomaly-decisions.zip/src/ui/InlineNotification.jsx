import { Icon } from './Icon.jsx';

// Рядок 1 — що сталося словами читача. Рядок 2 — чи можна вірити тому, що на екрані.
export function InlineNotification({ kind = 'error', title, children, onClose }) {
  return (
    <div className={`notification notification--${kind}`} role={kind === 'error' ? 'alert' : 'status'}>
      <span className="notification__icon"><Icon name={kind === 'error' ? 'error' : 'warning'} /></span>
      <div className="notification__body">
        <p className="notification__title">{title}</p>
        {children && <p className="notification__text">{children}</p>}
      </div>
      {onClose && (
        <button type="button" className="notification__close" onClick={onClose} aria-label="Закрити сповіщення">
          <Icon name="close" />
        </button>
      )}
    </div>
  );
}
