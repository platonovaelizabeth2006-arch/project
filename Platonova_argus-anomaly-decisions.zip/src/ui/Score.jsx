import { LEVEL_LABEL } from '../domain/anomalies.js';

// Оцінка 0–100 зі шкалою і словом рівня: число без шкали не каже, багато це чи мало.
export function Score({ value, level, compact = false }) {
  return (
    <span className={`score score--${level}${compact ? ' score--compact' : ''}`} aria-label={`Оцінка ${value} зі 100, ${LEVEL_LABEL[level].toLowerCase()}`}>
      <span className="score__num mono">{value}</span>
      <span className="score__bar" aria-hidden="true"><span style={{ width: `${value}%` }} /></span>
      {!compact && <span className="score__lvl">{LEVEL_LABEL[level]}</span>}
    </span>
  );
}
