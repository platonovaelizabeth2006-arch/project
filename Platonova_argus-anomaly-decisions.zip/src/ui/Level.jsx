import { LEVEL_LABEL as SEVERITY_LABEL } from '../domain/anomalies.js';

// Колір і слово завжди разом: квадрат сам по собі не є важливістю.
export function Level({ level, children }) {
  return (
    <span className={`severity severity--${level}`}>
      <span className="severity__mark" aria-hidden="true" />
      {children ?? SEVERITY_LABEL[level]}
    </span>
  );
}
