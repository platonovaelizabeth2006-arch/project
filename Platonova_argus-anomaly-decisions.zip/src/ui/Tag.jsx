// Тег — стан, а не дія. Кольори — пари з палітри тегів Carbon (контраст ≥ 4.5:1).
export function Tag({ type = 'gray', children }) {
  return <span className={`tag tag--${type}`}>{children}</span>;
}
