// Іконки в стилі Carbon: 16 px, обведення 1.2, колір — currentColor.
const PATHS = {
  add: 'M8 2.5v11M2.5 8h11',
  close: 'M3.5 3.5l9 9M12.5 3.5l-9 9',
  renew: 'M12.5 5.5A5 5 0 1 0 13 9M12.5 2v3.5H9',
  error: 'M8 4.5v4.5M8 11v.5M8 1.5a6.5 6.5 0 1 0 0 13 6.5 6.5 0 0 0 0-13z',
  check: 'M3 8.5l3 3 7-7',
  arrow: 'M3 8h10M9 4l4 4-4 4',
  back: 'M13 8H3M7 4L3 8l4 4',
  zones: 'M8 1.5l5.5 3.2v6.6L8 14.5l-5.5-3.2V4.7z',
  warning: 'M8 2l6.5 12h-13zM8 6.5v3.5M8 12v.3',
  list: 'M5 4h9M5 8h9M5 12h9M2 4h.5M2 8h.5M2 12h.5',
  send: 'M2 8l11-5.5-3.5 11-2.5-4.5zM8 9l5-6.5',
  sound: 'M2.5 6h2.5l3.5-3v10l-3.5-3H2.5zM11 5.5a3.5 3.5 0 0 1 0 5M12.5 3.5a6 6 0 0 1 0 9',
  mute: 'M2.5 6h2.5l3.5-3v10l-3.5-3H2.5zM11 6l3.5 4M14.5 6L11 10',
  boat: 'M2 10h12l-2 3H4zM8 3v7M8 3l4 5H8',
  radar: 'M8 1.5a6.5 6.5 0 1 0 0 13 6.5 6.5 0 0 0 0-13zM8 4.5a3.5 3.5 0 1 0 0 7 3.5 3.5 0 0 0 0-7zM8 8l4.5-4.5',
  plane: 'M8 1.5v13M2 9l6-3 6 3M5.5 14l2.5-1 2.5 1',
  users: 'M5.5 7a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5zM1.5 14c0-2.5 1.8-4 4-4s4 1.5 4 4M11 7a2 2 0 1 0 0-4M12 10c1.5.3 2.5 1.6 2.5 4',
  journal: 'M3 2h9.5v12H3zM5.5 2v12M7.5 5h3M7.5 7.5h3',
  chevron: 'M6 3.5l4.5 4.5L6 12.5',
};

export function Icon({ name, size = 16, title }) {
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none" stroke="currentColor"
      strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round"
      aria-hidden={title ? undefined : true} role={title ? 'img' : undefined} focusable="false">
      {title && <title>{title}</title>}
      <path d={PATHS[name]} />
    </svg>
  );
}
