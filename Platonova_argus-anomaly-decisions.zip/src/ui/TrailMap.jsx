import { AREA_NM, LAND, ORIGIN } from '../data/world.js';
import { toLocalNm } from '../domain/geo.js';

// Карта зі слідами: для аномальних треків — історія за 40 хв, щоб було видно саму поведінку (кола, розрив, стрибок).
// Колір — рівень аномалії; треки без аномалій — сірі, без сліду.
export function TrailMap({ histories, areas, anomalies, selectedId, onSelect, height = 560, focus = null }) {
  const proj = (p) => { const [x, y] = toLocalNm(p, ORIGIN); return [x, -y]; };
  const lvlOf = {};
  for (const a of anomalies) for (const id of a.trackIds) if (!lvlOf[id] || a.score > lvlOf[id].score) lvlOf[id] = a;
  const sel = anomalies.find((a) => a.id === selectedId);
  let vb = [AREA_NM.minX, -AREA_NM.maxY, AREA_NM.maxX - AREA_NM.minX, AREA_NM.maxY - AREA_NM.minY];
  if (focus) {
    const [cx, cy] = proj(focus);
    vb = [cx - 6, cy - 4.5, 12, 9];
  }
  const u = vb[2] / 100;
  const pts = (poly) => poly.map(proj).map(([x, y]) => `${x.toFixed(3)},${y.toFixed(3)}`).join(' ');
  return (
    <figure className="tmap2" style={{ height }}>
      <svg viewBox={vb.join(' ')} preserveAspectRatio="xMidYMid meet" role="img" aria-label={`Карта аномалій: ${anomalies.length} аномалій, ${histories.length} треків`}>
        <rect x={vb[0] - vb[2]} y={vb[1] - vb[3]} width={vb[2] * 3} height={vb[3] * 3} className="tmap2__water" />
        <polygon points={pts(LAND)} className="tmap2__land" />
        {areas.map((a) => <polygon key={a.id} points={pts(a.polygon)} className={`tmap2__area tmap2__area--${a.kind}`} strokeWidth={u * 0.2} strokeDasharray={`${u * 0.8} ${u * 0.5}`}><title>{a.name}</title></polygon>)}
        {histories.map((h) => {
          const an = lvlOf[h.id];
          if (!an || h.points.length < 2) return null;
          const isSel = sel?.trackIds.includes(h.id);
          // розрив у точках понад 5 хв малюється окремо — пунктиром, щоб «темний» період було видно
          const segs = [];
          let cur = [h.points[0]];
          for (let i = 1; i < h.points.length; i++) {
            const gap = (Date.parse(h.points[i].ts) - Date.parse(h.points[i - 1].ts)) / 60000;
            if (gap > 5) { segs.push({ pts: cur }); segs.push({ pts: [h.points[i - 1], h.points[i]], gap: true }); cur = [h.points[i]]; } else cur.push(h.points[i]);
          }
          segs.push({ pts: cur });
          return (
            <g key={`t${h.id}`} className={`tmap2__trail lvl--${an.level}${isSel ? ' is-selected' : ''}`}>
              {segs.map((s, i) => <polyline key={i} points={s.pts.map((p) => proj([p.lon, p.lat]).join(',')).join(' ')} strokeWidth={u * (isSel ? 0.35 : 0.22)} strokeDasharray={s.gap ? `${u} ${u * 0.7}` : undefined} fill="none" />)}
            </g>
          );
        })}
        {histories.map((h) => {
          const last = h.points[h.points.length - 1];
          if (!last) return null;
          const [x, y] = proj([last.lon, last.lat]);
          const an = lvlOf[h.id];
          const isSel = sel?.trackIds.includes(h.id);
          const s = u * 1.3;
          const name = h.name ?? h.id;
          const mark = h.domain === 'air'
            ? <polygon points={`0,${-s} ${s * 0.8},${s * 0.8} 0,${s * 0.3} ${-s * 0.8},${s * 0.8}`} />
            : <polygon points={`0,${-s} ${s * 0.6},${s * 0.8} ${-s * 0.6},${s * 0.8}`} />;
          return (
            <g key={h.id} className={`tmap2__trk lvl--${an ? an.level : 'none'}${isSel ? ' is-selected' : ''}`}
              {...(an && onSelect ? { role: 'button', tabIndex: 0, 'aria-label': `${name}: ${an.id}`, onClick: () => onSelect(an.id),
                onKeyDown: (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onSelect(an.id); } } } : {})}>
              <g transform={`translate(${x} ${y}) rotate(${last.cog ?? 0})`}>
                <circle r={s * 2.4} className="tmap2__hit" />
                {isSel && <circle r={s * 2} className="tmap2__ring" strokeWidth={u * 0.25} />}
                {mark}
              </g>
              {(an || focus) && <text x={x + s * 1.6} y={y - s * 0.6} fontSize={u * 1.6} className="tmap2__label">{name}</text>}
            </g>
          );
        })}
      </svg>
      <figcaption className="tmap2__legend">
        <span><i className="sw sw--high" />висока</span><span><i className="sw sw--medium" />середня</span><span><i className="sw sw--low" />низька</span>
        <span><i className="sw sw--gap" />розрив даних</span><span>лінія — рух за 40 хв</span>
      </figcaption>
    </figure>
  );
}
