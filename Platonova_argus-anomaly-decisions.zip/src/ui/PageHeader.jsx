export function PageHeader({ title, summary, actions, before }) {
  return (
    <div className="page-header">
      <div className="page-header__text">
        {before}
        <h1 className="page-title">{title}</h1>
        {summary && <p className="page-summary">{summary}</p>}
      </div>
      {actions && <div className="page-header__actions">{actions}</div>}
    </div>
  );
}
