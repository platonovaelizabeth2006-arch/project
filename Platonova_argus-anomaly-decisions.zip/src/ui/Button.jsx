import { Icon } from './Icon.jsx';

// kind: primary | secondary | ghost. Недоступну дію показують, а не ховають (handover, Button).
export function Button({ kind = 'secondary', size, icon, children, className = '', ...rest }) {
  const cls = ['btn', `btn--${kind}`, size === 'sm' && 'btn--sm', className].filter(Boolean).join(' ');
  return (
    <button type="button" className={cls} {...rest}>
      <span>{children}</span>
      {icon && <Icon name={icon} />}
    </button>
  );
}
