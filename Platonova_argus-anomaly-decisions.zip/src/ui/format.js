const timeFmt = new Intl.DateTimeFormat('uk-UA', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });
const dateFmt = new Intl.DateTimeFormat('uk-UA', { day: 'numeric', month: 'short' });

export const fmtTime = (t) => (t == null ? '—' : timeFmt.format(new Date(t)));

// Сьогодні — час, раніше — дата: так само, як у макеті Zones.
export function fmtWhen(t, now = Date.now()) {
  const d = new Date(t);
  return new Date(now).toDateString() === d.toDateString() ? fmtTime(d).slice(0, 5) : dateFmt.format(d);
}

export function fmtDuration(ms) {
  const min = Math.max(0, Math.floor(ms / 60000));
  if (min < 1) return 'менше 1 хв';
  if (min < 60) return `${min} хв`;
  const h = Math.floor(min / 60);
  return `${h} год ${String(min % 60).padStart(2, '0')} хв`;
}

export function fmtAgo(t, now = Date.now()) {
  const s = Math.floor((now - t) / 1000);
  if (s < 10) return 'щойно';
  if (s < 60) return `${s} с тому`;
  return `${fmtDuration(now - t)} тому`;
}

// Узгодження з числівником: 1 судно, 2 судна, 5 суден.
export function plural(n, one, few, many) {
  const m10 = n % 10, m100 = n % 100;
  if (m10 === 1 && m100 !== 11) return `${n} ${one}`;
  if (m10 >= 2 && m10 <= 4 && (m100 < 12 || m100 > 14)) return `${n} ${few}`;
  return `${n} ${many}`;
}
