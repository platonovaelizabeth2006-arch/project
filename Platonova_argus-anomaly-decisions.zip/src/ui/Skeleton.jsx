// Скелетон показує форму того, що надходить; сторінка не стрибає, коли дані прийдуть.
export function SkeletonBar({ width = '60%' }) {
  return <span className="skeleton" style={{ width }} />;
}

export function SkeletonBlock({ lines = 3 }) {
  const widths = ['70%', '45%', '85%', '55%', '65%'];
  return (
    <div className="skeleton-block" aria-hidden="true">
      {Array.from({ length: lines }, (_, i) => <SkeletonBar key={i} width={widths[i % widths.length]} />)}
    </div>
  );
}
