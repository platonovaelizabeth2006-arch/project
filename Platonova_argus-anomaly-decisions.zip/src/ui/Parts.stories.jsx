import { AREAS, historyAt } from '../data/world.js';
import { CLASS_MAX_KN } from '../data/world.js';
import { detectAll } from '../domain/anomalies.js';
import { Score } from './Score.jsx';
import { SeriesChart } from './SeriesChart.jsx';
import { Tag } from './Tag.jsx';
import { TrailMap } from './TrailMap.jsx';

export default { title: 'UI / Parts' };
const T0 = Date.parse('2026-11-14T11:00:00Z');
const H = historyAt(T0, T0);
const A = detectAll(H, AREAS, CLASS_MAX_KN);

export const Map = () => <TrailMap histories={H} areas={AREAS} anomalies={A} selectedId="rendezvous:trk-6102+trk-6103" onSelect={() => {}} height={620} />;
export const MapFocus = () => <TrailMap histories={H.filter((h) => h.id === 'trk-6101')} areas={AREAS} anomalies={A.filter((a) => a.id === 'loiter:trk-6101')} selectedId="loiter:trk-6101" focus={A.find((a) => a.id === 'loiter:trk-6101').at} height={360} />;
export const Scores = () => <div style={{ display: 'grid', gap: 12 }}><Score value={70} level="high" /><Score value={55} level="medium" /><Score value={15} level="low" /><Score value={65} level="medium" compact /></div>;
export const SpeedGap = () => <div style={{ maxWidth: 640 }}><SeriesChart points={H.find((h) => h.id === 'trk-6104').points} value={(p) => p.sog} label="Швидкість" unit="вуз" limit={14} limitLabel="типова макс. 14 вуз" /></div>;
export const Altitude = () => <div style={{ maxWidth: 640 }}><SeriesChart points={H.find((h) => h.id === 'trk-7101').points} value={(p) => p.alt} label="Висота" unit="футів" limit={1000} limitLabel="1000 футів" /></div>;
export const Tags = () => <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}><Tag type="red">Потребує рішення</Tag><Tag type="cyan">На спостереженні</Tag><Tag type="gray">Рішення ухвалено</Tag><Tag type="green">Підтвердилося</Tag><Tag type="red">Не підтвердилося</Tag><Tag type="blue">радимо</Tag></div>;
