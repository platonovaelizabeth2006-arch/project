// Графік значення в часі (швидкість або висота) з порогом. Розриви в даних не з'єднуються лінією.
export function SeriesChart({ points, value, label, unit, limit, limitLabel, height = 160 }) {
  if (!points.length) return null;
  const W = 600, H = height, pad = { l: 44, r: 12, t: 12, b: 26 };
  const t0 = Date.parse(points[0].ts), t1 = Date.parse(points[points.length - 1].ts) || t0 + 1;
  const vals = points.map(value);
  const max = Math.max(limit ?? 0, ...vals) * 1.15 || 1;
  const x = (p) => pad.l + ((Date.parse(p.ts) - t0) / (t1 - t0 || 1)) * (W - pad.l - pad.r);
  const y = (v) => pad.t + (1 - v / max) * (H - pad.t - pad.b);
  const segs = [];
  let cur = [points[0]];
  for (let i = 1; i < points.length; i++) {
    if (Date.parse(points[i].ts) - Date.parse(points[i - 1].ts) > 5 * 60000) { segs.push(cur); cur = []; }
    cur.push(points[i]);
  }
  segs.push(cur);
  const ticks = [0, 0.5, 1].map((k) => Math.round(max * k / 1.15));
  const minutesAgo = Math.round((t1 - t0) / 60000);
  return (
    <figure className="chart">
      <svg viewBox={`0 0 ${W} ${H}`} role="img" aria-label={`${label}: від ${Math.min(...vals)} до ${Math.max(...vals)} ${unit} за ${minutesAgo} хв`}>
        {ticks.map((v) => (
          <g key={v}><line x1={pad.l} x2={W - pad.r} y1={y(v)} y2={y(v)} className="chart__grid" /><text x={pad.l - 6} y={y(v) + 4} textAnchor="end" className="chart__tick">{v}</text></g>
        ))}
        {limit != null && <g><line x1={pad.l} x2={W - pad.r} y1={y(limit)} y2={y(limit)} className="chart__limit" /><text x={W - pad.r} y={y(limit) - 4} textAnchor="end" className="chart__limit-text">{limitLabel}</text></g>}
        {segs.map((s, i) => <polyline key={i} points={s.map((p) => `${x(p).toFixed(1)},${y(value(p)).toFixed(1)}`).join(' ')} className="chart__line" fill="none" />)}
        <text x={pad.l} y={H - 6} className="chart__tick">−{minutesAgo} хв</text>
        <text x={W - pad.r} y={H - 6} textAnchor="end" className="chart__tick">зараз</text>
      </svg>
      <figcaption className="chart__cap">{label}, {unit}</figcaption>
    </figure>
  );
}
