// Порожній стан каже, ЩО порожнє, ЧОМУ так може бути, і дає вихід.
export function EmptyState({ title, children, action }) {
  return (
    <div className="empty" role="status">
      <p className="empty__title">{title}</p>
      {children && <p className="empty__text">{children}</p>}
      {action}
    </div>
  );
}
