import { useSearchParams } from 'react-router';
import { TYPE_LABEL } from '../domain/anomalies.js';
import { ACTIONS, ACTION_TAG, reasonLabel } from '../domain/decisions.js';
import { useActions, useApp, useStats } from '../store/hooks.js';
import { Button } from '../ui/Button.jsx';
import { DataTable } from '../ui/DataTable.jsx';
import { EmptyState } from '../ui/EmptyState.jsx';
import { fmtTime } from '../ui/format.js';
import { REVIEW } from '../ui/labels.js';
import { Score } from '../ui/Score.jsx';
import { Select } from '../ui/Select.jsx';
import { Tag } from '../ui/Tag.jsx';

// Журнал рішень і розбір: чи підтвердилося рішення. Статистика за типами показує, де пороги дають хибні тривоги.
export function DecisionsView() {
  const archive = useApp((s) => s.archive);
  const { review } = useActions();
  const st = useStats();
  const [params, setParams] = useSearchParams();
  const f = params.get('review') ?? 'all';
  const rows = archive.filter((d) => (f === 'all' ? true : f === 'pending' ? !d.review : d.review === f));
  const cols = [
    { key: 'at', header: 'Час', width: 90, render: (d) => <span className="mono">{fmtTime(d.at).slice(0, 5)}</span> },
    { key: 'a', header: 'Аномалія', render: (d) => (<><span className="cell-title">{TYPE_LABEL[d.type]}</span><span className="cell-sub">{d.trackIds.join(' + ')}</span></>) },
    { key: 's', header: 'Оцінка', width: 120, render: (d) => <Score value={d.score} level={d.level} compact /> },
    { key: 'd', header: 'Рішення', width: 260, render: (d) => (<><Tag type={ACTION_TAG[d.action]}>{ACTIONS[d.action].label}</Tag><span className="cell-sub">{reasonLabel(d.action, d.reason)}{d.followed ? '' : ' · не за рекомендацією'}</span></>) },
    { key: 'r', header: 'Розбір', width: 260, render: (d) => (d.review
      ? <Tag type={REVIEW[d.review].tag}>{REVIEW[d.review].label}</Tag>
      : <span className="actions"><Button kind="ghost" size="sm" onClick={(e) => { e.stopPropagation(); review(d.id, 'confirmed'); }}>Підтвердилося</Button><Button kind="ghost" size="sm" onClick={(e) => { e.stopPropagation(); review(d.id, 'refuted'); }}>Ні</Button></span>) },
  ];
  return (
    <>
      <div className="page-header"><div className="page-header__text">
        <h1 className="page-title">Журнал рішень</h1>
        <p className="page-summary">{archive.length ? `рішень ${archive.length} · без розбору ${archive.filter((d) => !d.review).length}` : 'Рішень ще не ухвалено'}</p>
      </div></div>
      {st.length > 0 && (
        <table className="stats" aria-label="Статистика за типами">
          <thead><tr><th>Тип аномалії</th><th className="num">Рішень</th><th className="num">За рекомендацією</th><th className="num">Розібрано</th><th className="num">Не підтвердилося</th></tr></thead>
          <tbody>{st.map((s) => (
            <tr key={s.type}><td>{TYPE_LABEL[s.type]}</td><td className="num">{s.total}</td><td className="num">{s.followed}</td><td className="num">{s.reviewed}</td>
              <td className="num">{s.refutedShare == null ? '—' : <span className={s.refutedShare >= 50 ? 'warn-text' : ''}>{s.refutedShare}%</span>}</td></tr>
          ))}</tbody>
        </table>
      )}
      <div className="toolbar">
        <Select label="Розбір" value={f} onChange={(v) => setParams(v === 'all' ? {} : { review: v }, { replace: true })}
          options={[{ value: 'all', label: 'Усі' }, { value: 'pending', label: 'Без розбору' }, { value: 'confirmed', label: 'Підтвердилося' }, { value: 'refuted', label: 'Не підтвердилося' }]} />
      </div>
      <DataTable label="Журнал рішень" columns={cols} rows={rows} getKey={(d) => d.id} edgeOf={(d) => d.level}
        empty={archive.length ? <EmptyState title="Немає рішень з таким розбором" action={<Button onClick={() => setParams({}, { replace: true })}>Показати всі</Button>} />
          : <EmptyState title="Журнал рішень порожній">Кожне рішення щодо аномалії записується сюди з обґрунтуванням. Пізніше відмітьте, чи воно підтвердилося, — так видно, які ознаки дають хибні тривоги.</EmptyState>}
        footer={archive.length ? `Показано ${rows.length} з ${archive.length}` : null} />
    </>
  );
}
