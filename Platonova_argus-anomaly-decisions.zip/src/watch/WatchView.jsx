import { Link } from 'react-router';
import { TYPE_LABEL } from '../domain/anomalies.js';
import { useAnomalies, useApp, useLoadState } from '../store/hooks.js';
import { EmptyState } from '../ui/EmptyState.jsx';
import { fmtTime } from '../ui/format.js';
import { mins } from '../ui/labels.js';
import { Score } from '../ui/Score.jsx';
import { Tag } from '../ui/Tag.jsx';

// Спостереження: об'єкти, за якими оператор вирішив стежити, і скільки лишилося до повернення на рішення.
export function WatchView() {
  const { updatedAt } = useLoadState();
  const archive = useApp((s) => s.archive);
  const current = Object.fromEntries(useAnomalies().map((a) => [a.id, a]));
  const latest = Object.values(Object.fromEntries([...archive].reverse().map((d) => [d.anomalyId, d])));
  const watches = latest.filter((d) => d.action === 'watch').sort((x, y) => x.until - y.until);
  const active = watches.filter((d) => d.until > (updatedAt ?? 0));
  const done = watches.filter((d) => d.until <= (updatedAt ?? 0));
  const Row = ({ d, over }) => {
    const a = current[d.anomalyId];
    const total = d.until - d.at, left = d.until - (updatedAt ?? 0);
    return (
      <li className={`wcard edge--${d.level}`}>
        <div className="wcard__top"><span className="cell-title">{TYPE_LABEL[d.type]}: {a?.title ?? d.trackIds.join(' + ')}</span><Score value={a?.score ?? d.score} level={a?.level ?? d.level} compact /></div>
        {!over && <div className="wcard__bar" aria-hidden="true"><span style={{ width: `${Math.max(0, Math.min(100, (left / total) * 100))}%` }} /></div>}
        <p className="muted">{over ? `Спостереження завершилося о ${fmtTime(d.until)}` : `До ${fmtTime(d.until)} · лишилось ${mins(left)}`}{a && a.score > d.score ? ` · оцінка зросла з ${d.score} до ${a.score}` : ''}{!a ? ' · ознаки зникли' : ''}</p>
        {a ? <Link className="inline-link" to={`/anomalies/${encodeURIComponent(d.anomalyId)}`}>{over ? 'Ухвалити рішення' : 'Картка рішення'}</Link> : <Tag type="gray">Немає в обстановці</Tag>}
      </li>
    );
  };
  return (
    <>
      <div className="page-header"><div className="page-header__text">
        <h1 className="page-title">Спостереження</h1>
        <p className="page-summary">{`на спостереженні ${active.length} · завершено ${done.length}`}</p>
      </div></div>
      {watches.length === 0 && <EmptyState title="Нічого не на спостереженні">Оберіть «Спостерігати» в картці рішення — об'єкт з'явиться тут і повернеться на рішення, коли час мине.</EmptyState>}
      {done.length > 0 && <><h2 className="section-title">Потребують рішення</h2><ul className="wlist" aria-label="Завершені спостереження">{done.map((d) => <Row key={d.id} d={d} over />)}</ul></>}
      {active.length > 0 && <><h2 className="section-title">Тривають</h2><ul className="wlist" aria-label="Тривають">{active.map((d) => <Row key={d.id} d={d} />)}</ul></>}
    </>
  );
}
