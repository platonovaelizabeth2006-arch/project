import { useState } from 'react';
import { Link, useParams } from 'react-router';
import { TYPE_LABEL } from '../domain/anomalies.js';
import { ACTIONS, ACTION_TAG, reasonLabel, reasonsFor, validateDecision, WATCH_OPTIONS } from '../domain/decisions.js';
import { CLASS_MAX_KN } from '../data/world.js';
import { lastUpdated, StatusNotice } from '../shell/StatusNotice.jsx';
import { useActions, useAnomalies, useApp, useLoadState } from '../store/hooks.js';
import { Button } from '../ui/Button.jsx';
import { EmptyState } from '../ui/EmptyState.jsx';
import { fmtTime } from '../ui/format.js';
import { Icon } from '../ui/Icon.jsx';
import { CLASS_LABEL, KIND_LABEL, mins, REVIEW, SOURCE_LABEL, statusTag } from '../ui/labels.js';
import { PageHeader } from '../ui/PageHeader.jsx';
import { Score } from '../ui/Score.jsx';
import { Select } from '../ui/Select.jsx';
import { SeriesChart } from '../ui/SeriesChart.jsx';
import { SkeletonBlock } from '../ui/Skeleton.jsx';
import { Tag } from '../ui/Tag.jsx';
import { TrailMap } from '../ui/TrailMap.jsx';

const back = <Link className="back-link" to="/anomalies"><Icon name="back" />Аномалії руху</Link>;

// Картка рішення: з чого складається оцінка, як поводився об'єкт, що радимо і чому, які варіанти і їхні наслідки.
export function AnomalyView() {
  const id = decodeURIComponent(useParams().anomalyId);
  const { status, updatedAt } = useLoadState();
  const { start, decide, review } = useActions();
  const areas = useApp((s) => s.areas);
  const histories = useApp((s) => s.histories);
  const archive = useApp((s) => s.archive);
  const a = useAnomalies().find((x) => x.id === id);
  const [form, setForm] = useState({ action: '', reason: '', note: '', minutes: '' });
  const [errors, setErrors] = useState({});
  const [busy, setBusy] = useState(false);
  const [edit, setEdit] = useState(false);

  if (status === 'loading') return <><PageHeader before={back} title="Картка рішення" summary="Завантаження…" /><SkeletonBlock lines={6} /></>;
  if (status === 'error') return <><PageHeader before={back} title="Картка рішення" summary="Дані недоступні" actions={<Button kind="primary" icon="renew" onClick={start}>Спробувати ще</Button>} /><StatusNotice /></>;
  if (!a) {
    return (
      <><PageHeader before={back} title="Картка рішення" />
        <EmptyState title="Цієї аномалії зараз немає в обстановці" action={<Link className="btn btn--secondary" to="/decisions"><span>До журналу рішень</span></Link>}>
          Ознаки могли зникнути з 40-хвилинної історії треку. Ухвалені рішення збережено в журналі.
        </EmptyState></>
    );
  }
  const st = statusTag(a);
  const action = form.action || a.rec.action;
  const history = archive.filter((d) => d.anomalyId === a.id);
  const others = archive.filter((d) => d.anomalyId !== a.id && d.trackIds.some((t) => a.trackIds.includes(t)));
  const showForm = !a.decision || a.needs || edit;
  const set = (k) => (v) => setForm((f) => ({ ...f, [k]: v }));

  async function submit(e) {
    e.preventDefault();
    const d = { ...form, action, minutes: Number(form.minutes) || 0, recommended: a.rec.action };
    const errs = validateDecision(d);
    setErrors(errs);
    if (Object.keys(errs).length) return;
    setBusy(true);
    const r = await decide(a.id, d);
    setBusy(false);
    if (!r.ok) setErrors({ submit: r.error });
    else { setForm({ action: '', reason: '', note: '', minutes: '' }); setEdit(false); }
  }

  return (
    <>
      <PageHeader before={back} title={`${TYPE_LABEL[a.type]}: ${a.title}`}
        summary={[a.id, `ознаки з ${fmtTime(Date.parse(a.since))}`, lastUpdated(updatedAt)].join(' · ')} />
      <StatusNotice />
      <div className="detail">
        <div className="detail__main">
          <section className={`panel alert-card edge--${a.level}`} aria-label="Оцінка">
            <div className="alert-card__head"><Score value={a.score} level={a.level} /><span className="alert-card__tags"><Tag type={st.tag}>{st.label}</Tag></span></div>
            <table className="evidence" aria-label="З чого складається оцінка">
              <thead><tr><th>Ознака</th><th>Що саме</th><th className="num">Бали</th></tr></thead>
              <tbody>
                {a.indicators.map((i) => (
                  <tr key={i.code} className={i.weight < 0 ? 'is-minus' : ''}>
                    <td>{i.label}</td><td className="muted">{i.detail}</td>
                    <td className="num"><span className="evidence__bar" aria-hidden="true"><span style={{ width: `${Math.abs(i.weight)}%` }} /></span><span className="mono">{i.weight > 0 ? `+${i.weight}` : i.weight}</span></td>
                  </tr>
                ))}
                <tr className="evidence__total"><td colSpan={2}>Разом (від 0 до 100)</td><td className="num mono">{a.score}</td></tr>
              </tbody>
            </table>
          </section>
          {a.tracks.map((t) => (
            <section key={t.id} className="panel" aria-label={`Рух ${t.name ?? t.id}`}>
              <h2 className="panel__title">{t.name ?? t.id} <span className="id">{t.id}</span></h2>
              <p className="panel__sub">{CLASS_LABEL[t.classification]}, {KIND_LABEL[t.kind]} · {SOURCE_LABEL[t.source]} · точок в історії {t.points.length}</p>
              {t.domain === 'air'
                ? <SeriesChart points={t.points} value={(p) => p.alt ?? 0} label="Висота" unit="футів" limit={1000} limitLabel="1000 футів" />
                : <SeriesChart points={t.points.filter((p) => p.sog < 60)} value={(p) => p.sog} label="Швидкість" unit="вуз" limit={CLASS_MAX_KN[t.kind]} limitLabel={`типова макс. для класу: ${CLASS_MAX_KN[t.kind]} вуз`} />}
            </section>
          ))}
          <TrailMap histories={histories.filter((h) => a.trackIds.includes(h.id))} areas={areas} anomalies={[a]} selectedId={a.id} focus={a.at} height={320} />
        </div>
        <div className="detail__side">
          <section className="panel rec" aria-label="Рекомендація">
            <p className="rec__label">Радимо</p>
            <p className="rec__action">{ACTIONS[a.rec.action].label}</p>
            <p className="rec__why">{a.rec.why}</p>
          </section>
          {a.decision && !edit && (
            <section className="panel" aria-label="Ухвалене рішення">
              <h2 className="panel__title">Ухвалене рішення</h2>
              <p><Tag type={ACTION_TAG[a.decision.action]}>{ACTIONS[a.decision.action].label}</Tag> о {fmtTime(a.decision.at)}{a.decision.followed ? '' : ' · не за рекомендацією'}</p>
              <dl className="props">
                <dt>Обґрунтування</dt><dd>{reasonLabel(a.decision.action, a.decision.reason)}{a.decision.note ? ` — ${a.decision.note}` : ''}</dd>
                {a.decision.until && <><dt>{a.decision.action === 'watch' ? 'Спостерігати до' : 'Знято до'}</dt><dd>{fmtTime(a.decision.until)}{updatedAt < a.decision.until ? ` · лишилось ${mins(a.decision.until - updatedAt)}` : ''}</dd></>}
                {a.decision.ref && <><dt>Запис у SENTINEL</dt><dd className="mono">{a.decision.ref}</dd></>}
                <dt>Розбір</dt><dd>{a.decision.review ? <Tag type={REVIEW[a.decision.review].tag}>{REVIEW[a.decision.review].label}</Tag> : 'ще не проведено'}</dd>
              </dl>
              {!a.decision.review && (
                <div className="actions">
                  <Button kind="secondary" size="sm" onClick={() => review(a.decision.id, 'confirmed')}>Рішення підтвердилося</Button>
                  <Button kind="secondary" size="sm" onClick={() => review(a.decision.id, 'refuted')}>Не підтвердилося</Button>
                </div>
              )}
              {!a.needs && <Button kind="ghost" size="sm" onClick={() => setEdit(true)}>Змінити рішення…</Button>}
            </section>
          )}
          {showForm && (
            <form className="panel form-stack" onSubmit={submit} aria-label="Рішення" noValidate>
              <h2 className="panel__title">{a.decision ? 'Нове рішення' : 'Рішення'}</h2>
              {a.status === 'expired' && <p className="reack">Спостереження завершилося — потрібне рішення.</p>}
              {a.status === 'escalated' && <p className="reack">Оцінка зросла з {a.decision.score} до {a.score} після попереднього рішення.</p>}
              <fieldset className="options">
                <legend className="field__label">Варіант дії</legend>
                {Object.entries(ACTIONS).map(([k, v]) => (
                  <label key={k} className={`option${action === k ? ' is-checked' : ''}`}>
                    <input type="radio" name="action" value={k} checked={action === k} onChange={() => set('action')(k)} />
                    <span><span className="option__title">{v.label}{k === a.rec.action && <Tag type="blue">радимо</Tag>}</span><span className="option__effect">{v.effect}</span></span>
                  </label>
                ))}
              </fieldset>
              {action === 'watch' && <Select label="Скільки спостерігати" value={form.minutes} onChange={set('minutes')} error={errors.minutes} options={[{ value: '', label: 'Оберіть' }, ...WATCH_OPTIONS.map((m) => ({ value: String(m), label: `${m} хв` }))]} />}
              <Select label="Обґрунтування" value={form.reason} onChange={set('reason')} error={errors.reason} options={[{ value: '', label: 'Оберіть' }, ...reasonsFor(action)]} />
              <div className="field"><label className="field__label" htmlFor="dn">Примітка</label>
                <textarea id="dn" className="field__control field__control--area" rows={2} value={form.note} onChange={(e) => set('note')(e.target.value)} maxLength={300} />
                {errors.note && <span className="field__error">{errors.note}</span>}</div>
              {errors.submit && <p className="field__error" role="alert">Рішення не записано: {errors.submit}</p>}
              <div className="actions">
                <Button kind="primary" type="submit" icon="check" disabled={busy}>{busy ? 'Записується…' : 'Ухвалити рішення'}</Button>
                {edit && <Button kind="ghost" onClick={() => setEdit(false)}>Скасувати</Button>}
              </div>
            </form>
          )}
          <section className="panel" aria-label="Попередні рішення">
            <h2 className="panel__title">Попередні рішення щодо цих об'єктів</h2>
            {history.length + others.length === 0 ? <p className="muted">Рішень щодо цих об'єктів ще не було.</p> : (
              <ul className="plain">
                {[...history, ...others].map((d) => (
                  <li key={d.id}><span className="mono">{fmtTime(d.at)}</span> {TYPE_LABEL[d.type]} — <Tag type={ACTION_TAG[d.action]}>{ACTIONS[d.action].label}</Tag>{d.review && <> <Tag type={REVIEW[d.review].tag}>{REVIEW[d.review].label}</Tag></>}</li>
                ))}
              </ul>
            )}
          </section>
        </div>
      </div>
    </>
  );
}
