import { Link, useSearchParams } from 'react-router';
import { TYPE_LABEL } from '../domain/anomalies.js';
import { ACTIONS } from '../domain/decisions.js';
import { lastUpdated, StatusNotice } from '../shell/StatusNotice.jsx';
import { useActions, useAnomalies, useApp, useLoadState } from '../store/hooks.js';
import { Button } from '../ui/Button.jsx';
import { EmptyState } from '../ui/EmptyState.jsx';
import { Icon } from '../ui/Icon.jsx';
import { statusTag } from '../ui/labels.js';
import { Score } from '../ui/Score.jsx';
import { SkeletonBlock } from '../ui/Skeleton.jsx';
import { Tag } from '../ui/Tag.jsx';
import { TrailMap } from '../ui/TrailMap.jsx';

const SHOW = [{ v: 'needs', l: 'Потребують рішення' }, { v: 'all', l: 'Усі' }];

// Черга аномалій: ліворуч карта зі слідами руху, праворуч — аномалії від тих, що потребують рішення, за оцінкою.
export function AnomaliesView() {
  const { status, stale, updatedAt } = useLoadState();
  const { start } = useActions();
  const histories = useApp((s) => s.histories);
  const areas = useApp((s) => s.areas);
  const all = useAnomalies();
  const [params, setParams] = useSearchParams();
  const show = params.get('show') === 'all' ? 'all' : 'needs';
  const selectedId = params.get('a') ?? '';
  const set = (k, v) => { const n = new URLSearchParams(params); if (v) n.set(k, v); else n.delete(k); setParams(n, { replace: true }); };
  const items = show === 'all' ? all : all.filter((a) => a.needs);
  const needs = all.filter((a) => a.needs).length;

  if (status === 'loading') {
    return <div className="overview"><div className="map-skeleton map-skeleton--full" aria-label="Завантаження карти" /><aside className="overview__side"><h1 className="page-title">Аномалії руху</h1><p className="page-summary">Аналіз історії треків…</p><SkeletonBlock lines={6} /></aside></div>;
  }
  if (status === 'error') {
    return <div className="page-pad"><h1 className="page-title">Аномалії руху</h1><p className="page-summary">Дані недоступні</p><StatusNotice /><Button kind="primary" icon="renew" onClick={start}>Спробувати ще</Button></div>;
  }
  return (
    <div className="overview">
      <div className={`overview__map overview__map--full${stale ? ' is-stale' : ''}`}>
        <TrailMap histories={histories} areas={areas} anomalies={all} selectedId={selectedId} onSelect={(id) => set('a', id === selectedId ? '' : id)} height="calc(100vh - 48px)" />
        {histories.length === 0 && <div className="map-overlay"><EmptyState title="У районі зараз немає треків">Аналізувати нічого: аномалії з'являться, щойно з'являться треки з історією руху.</EmptyState></div>}
      </div>
      <aside className="overview__side" aria-label="Черга аномалій">
        <h1 className="page-title">Аномалії руху</h1>
        <p className="page-summary">{[`потребують рішення ${needs}`, `усього ${all.length}`, lastUpdated(updatedAt)].join(' · ')}</p>
        <StatusNotice />
        <div className="seg" role="group" aria-label="Які аномалії показати">
          {SHOW.map((s) => <button key={s.v} type="button" className="seg__btn" aria-pressed={show === s.v} onClick={() => set('show', s.v === 'needs' ? '' : s.v)}>{s.l}</button>)}
        </div>
        {items.length === 0 && (
          all.length === 0
            ? <EmptyState title="Аномалій не виявлено">Рух у районі відповідає звичайному: жодна ознака не набрала 15 балів з урахуванням районів.</EmptyState>
            : <EmptyState title="Усі аномалії мають рішення" action={<Button onClick={() => set('show', 'all')}>Показати всі ({all.length})</Button>}>Нові з'являться тут, а також ті, де закінчилося спостереження або посилились ознаки.</EmptyState>
        )}
        <ul className="aqueue" aria-label="Аномалії">
          {items.map((a) => {
            const st = statusTag(a);
            return (
              <li key={a.id}>
                <div className={`aq edge--${a.level}${a.id === selectedId ? ' is-selected' : ''}`}>
                  <button type="button" className="aq__main" aria-pressed={a.id === selectedId} onClick={() => set('a', a.id === selectedId ? '' : a.id)}>
                    <span className="aq__top"><span className="aq__type">{TYPE_LABEL[a.type]}</span><Score value={a.score} level={a.level} compact /></span>
                    <span className="aq__who">{a.title}</span>
                    <span className="aq__why">{a.indicators.filter((i) => i.weight > 0).map((i) => i.label).join(' · ')}</span>
                    <span className="aq__tags"><Tag type={st.tag}>{st.label}</Tag>{a.needs && <span className="muted">радимо: {ACTIONS[a.rec.action].label.toLowerCase()}</span>}</span>
                  </button>
                  <Link className="aq__open" to={`/anomalies/${encodeURIComponent(a.id)}`} aria-label={`Картка рішення: ${a.title}`}><Icon name="chevron" /></Link>
                </div>
              </li>
            );
          })}
        </ul>
      </aside>
    </div>
  );
}
