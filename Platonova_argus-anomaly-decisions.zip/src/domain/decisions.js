import { TYPE } from './anomalies.js';

// Варіанти рішення щодо аномалії. Кожен має наслідок — що станеться після вибору, щоб оператор бачив ціну рішення.
export const ACTIONS = {
  dismiss: { label: 'Визнати нормою', effect: 'Аномалію знято з розгляду на 2 год для цього об\'єкта. Якщо ознаки посиляться — вона повернеться.' },
  watch: { label: 'Спостерігати', effect: 'Об\'єкт у списку спостереження на обраний час; після нього аномалія повернеться на рішення.' },
  contact: { label: 'Викликати на зв\'язок через СУРС', effect: 'Запит судну по УКХ через СУРС: пояснити рух. Відповідь вноситься приміткою.' },
  verify: { label: 'Направити засіб для перевірки', effect: 'Запит на спостереження (POST /v1/collection-requests) — черговий призначить платформу.' },
  escalate: { label: 'Доповісти старшому зміни', effect: 'Аномалія передається старшому як подія високої важливості.' },
};
export const ACTION_TAG = { dismiss: 'gray', watch: 'cyan', contact: 'blue', verify: 'blue', escalate: 'red' };

export const REASONS = {
  dismiss: [
    { value: 'known_activity', label: 'Відома законна діяльність (роботи, навчання, промисел)' },
    { value: 'sensor_error', label: 'Помилка датчика або зав\'язки треку' },
    { value: 'confirmed_by_report', label: 'Підтверджено донесенням або відповіддю судна' },
    { value: 'other', label: 'Інше — пояснення в примітці' },
  ],
  default: [
    { value: 'score', label: 'Оцінка і ознаки виправдовують дію' },
    { value: 'context', label: 'Обстановка в районі вимагає уваги' },
    { value: 'repeat', label: 'Об\'єкт уже мав аномалії раніше' },
    { value: 'other', label: 'Інше — пояснення в примітці' },
  ],
};
export const reasonsFor = (action) => REASONS[action === 'dismiss' ? 'dismiss' : 'default'];
export const reasonLabel = (action, v) => reasonsFor(action).find((r) => r.value === v)?.label ?? v;

export const WATCH_OPTIONS = [30, 60, 120];
export const DISMISS_HOURS = 2;

// Що радити: за типом аномалії і її рівнем. Пояснення — одне речення, яке оператор може повторити старшому.
export function recommend(a, { hasAis }) {
  if (a.level === 'low') return { action: 'watch', why: 'Оцінка низька: досить спостерігати, щоб не пропустити посилення ознак.' };
  switch (a.type) {
    case TYPE.MEET: return { action: 'verify', why: 'Зустріч у морі з судном без AIS — типова картина перевантаження; підтвердити може лише засіб на місці.' };
    case TYPE.DARK: return a.level === 'high'
      ? { action: 'verify', why: 'Вимкнення AIS разом з неможливою для класу швидкістю: судно приховувало, куди ходило.' }
      : { action: 'contact', why: 'Розрив AIS часто технічний — спершу запитати судно.' };
    case TYPE.JUMP: return { action: 'contact', why: 'Стрибок з поверненням — ознака підміни координат; судно може не знати, що його AIS бреше.' };
    case TYPE.CIRCLE: return { action: 'escalate', why: 'Невідомий повітряний об\'єкт кружляє низько над районом — це вирішує не лише морський черговий.' };
    case TYPE.LOITER: return hasAis
      ? { action: 'contact', why: 'Судно з AIS — найшвидше запитати, чому воно кружляє над трубопроводом.' }
      : { action: 'verify', why: 'Без AIS судно не запитати — потрібен засіб на місці.' };
    default: return { action: 'watch', why: 'Невідомий тип аномалії — спостерігати.' };
  }
}

export function validateDecision({ action, reason, note, minutes }) {
  const e = {};
  if (!action) e.action = 'Оберіть рішення.';
  if (!reason) e.reason = 'Оберіть обґрунтування — без нього рішення не можна буде пояснити на розборі.';
  if (reason === 'other' && !note?.trim()) e.note = 'Для «Інше» напишіть пояснення.';
  if (action === 'watch' && !minutes) e.minutes = 'Оберіть, скільки спостерігати.';
  if (note && note.length > 300) e.note = 'Не більше 300 символів.';
  return e;
}

export function makeDecision(a, d, now) {
  return {
    anomalyId: a.id, type: a.type, trackIds: a.trackIds, score: a.score, level: a.level,
    action: d.action, reason: d.reason, note: d.note?.trim() ?? '', at: now,
    until: d.action === 'watch' ? now + d.minutes * 60000 : d.action === 'dismiss' ? now + DISMISS_HOURS * 3600000 : null,
    recommended: d.recommended, followed: d.action === d.recommended,
    review: null, reviewedAt: null,
  };
}

// Стан аномалії для черги: нова — рішення немає або спостереження скінчилося; на спостереженні; вирішена.
export function statusOf(a, decision, now) {
  if (!decision) return 'new';
  if (decision.action === 'watch') return now < decision.until ? 'watch' : 'expired';
  if (decision.action === 'dismiss' && now >= decision.until) return 'new';
  // посилення ознак повертає аномалію на рішення
  if (a.score >= decision.score + 15) return 'escalated';
  return 'decided';
}
export const STATUS_LABEL = { new: 'Потребує рішення', expired: 'Спостереження завершено', escalated: 'Ознаки посилились', watch: 'На спостереженні', decided: 'Рішення ухвалено' };
export const STATUS_TAG = { new: 'red', expired: 'red', escalated: 'red', watch: 'cyan', decided: 'gray' };
export const needsDecision = (s) => s === 'new' || s === 'expired' || s === 'escalated';

// Статистика рішень за типами: скільки переглянуто і яка частка не підтвердилася — підказка планувальнику про пороги.
export function stats(decisions) {
  const by = {};
  for (const d of decisions) {
    const s = (by[d.type] ??= { type: d.type, total: 0, reviewed: 0, refuted: 0, followed: 0 });
    s.total += 1;
    if (d.followed) s.followed += 1;
    if (d.review) s.reviewed += 1;
    if (d.review === 'refuted') s.refuted += 1;
  }
  return Object.values(by).map((s) => ({ ...s, refutedShare: s.reviewed ? Math.round((s.refuted / s.reviewed) * 100) : null }));
}
