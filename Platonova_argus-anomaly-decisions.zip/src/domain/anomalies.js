import { distanceNm, headingDiff, pointInPolygon } from './geo.js';

// ---------------------------------------------------------------------------
// Виявлення аномалій в історії треків і оцінка їхньої вагомості.
// Кожна аномалія — сума ознак з вагами плюс поправка на район. Оператор бачить кожну ознаку і її внесок:
// оцінка, яку не можна пояснити, не допомагає ухвалити рішення.
// ---------------------------------------------------------------------------

export const TYPE = { LOITER: 'loiter', MEET: 'rendezvous', DARK: 'dark', SPEED: 'speed', JUMP: 'jump', CIRCLE: 'air_circle' };
export const TYPE_LABEL = {
  loiter: 'Кружляння на місці', rendezvous: 'Зустріч суден у морі', dark: 'Вимкнення AIS',
  speed: 'Нетипова швидкість', jump: 'Стрибок координат', air_circle: 'Кружляння на малій висоті',
};
export const LEVEL_LABEL = { high: 'Висока', medium: 'Середня', low: 'Низька' };

// Пороги — що вважати аномалією. Їх встановлює планувальник; тут — значення за замовчуванням.
export const T = {
  LOITER_MIN: 20, LOITER_RADIUS_NM: 0.8, LOITER_PATH_NM: 1.5,
  MEET_NM: 0.3, MEET_MIN: 10, MEET_MAX_KN: 3,
  DARK_MIN: 5,
  JUMP_KN: 100, JUMP_RETURN_MIN: 5,
  CIRCLE_MIN: 10, CIRCLE_DEG: 720, LOW_FT: 1000,
  SHOW: 15, MEDIUM: 40, HIGH: 70,
};

export const W = {
  loiter: { label: 'Кружляє на місці понад 20 хв', w: 35 },
  near_critical: { label: 'Над критичним об\'єктом', w: 30 },
  meet: { label: 'Два судна борт до борту в морі', w: 50 },
  partner_dark: { label: 'Одне з суден без AIS', w: 20 },
  dark: { label: 'AIS мовчав', w: 40 },
  speed_class: { label: 'Швидкість, неможлива для класу судна', w: 30 },
  jump: { label: 'Положення змістилося неможливо швидко', w: 45 },
  returned: { label: 'Повернулося на попередній курс — ознака підміни', w: 10 },
  circling: { label: 'Кружляє в повітрі', w: 35 },
  low: { label: 'Висота нижче 1000 футів', w: 25 },
  unknown: { label: 'Об\'єкт не ідентифіковано', w: 10 },
  area_normal: { label: 'У районі, де це звичайно', w: -20 },
  area_approach: { label: 'У секторі аеродрому — низька висота звичайна', w: -40 },
};

const ms = (iso) => Date.parse(iso);
const pos = (p) => [p.lon, p.lat];
const lastMinutes = (points, min) => {
  if (!points.length) return [];
  const end = ms(points[points.length - 1].ts);
  return points.filter((p) => end - ms(p.ts) <= min * 60000);
};

export function areaOf(p, areas) {
  return areas.find((a) => pointInPolygon(pos(p), a.polygon)) ?? null;
}

const ind = (code, detail) => ({ code, label: W[code].label, weight: W[code].w, detail });

export function levelOf(score) {
  if (score >= T.HIGH) return 'high';
  if (score >= T.MEDIUM) return 'medium';
  return 'low';
}

function finish(a) {
  const score = Math.max(0, Math.min(100, a.indicators.reduce((s, i) => s + i.weight, 0)));
  return { ...a, score, level: levelOf(score) };
}

// Кружляння: за останні 20 хв судно пройшло чимало, але лишилося в колі 0,8 милі.
export function detectLoiter(track, areas) {
  if (track.domain !== 'sea') return null;
  const pts = lastMinutes(track.points, T.LOITER_MIN);
  if (pts.length < 2 || (ms(pts[pts.length - 1].ts) - ms(pts[0].ts)) < (T.LOITER_MIN - 1) * 60000) return null;
  const c = [pts.reduce((s, p) => s + p.lon, 0) / pts.length, pts.reduce((s, p) => s + p.lat, 0) / pts.length];
  const radius = Math.max(...pts.map((p) => distanceNm(c, pos(p))));
  let path = 0;
  for (let i = 1; i < pts.length; i++) path += distanceNm(pos(pts[i - 1]), pos(pts[i]));
  if (radius > T.LOITER_RADIUS_NM || path < T.LOITER_PATH_NM) return null;
  const area = areaOf(pts[pts.length - 1], areas);
  const indicators = [ind('loiter', `${path.toFixed(1)} милі в колі ${radius.toFixed(2)} милі`)];
  if (area?.effect === 'raise') indicators.push(ind('near_critical', area.name));
  if (area?.effect === 'normal_loiter' || area?.effect === 'normal_stop') indicators.push(ind('area_normal', area.name));
  if (track.classification === 'unknown') indicators.push(ind('unknown', 'класифікація: невідомий'));
  return finish({ type: TYPE.LOITER, trackIds: [track.id], indicators, since: pts[0].ts, at: pos(pts[pts.length - 1]), areaId: area?.id ?? null });
}

// Зустріч: два надводні треки повільно стоять ближче 0,3 милі один до одного 10 хв і довше, поза портом і стоянкою.
export function detectMeetings(tracks, areas) {
  const sea = tracks.filter((t) => t.domain === 'sea' && t.classification !== 'friendly');
  const out = [];
  for (let i = 0; i < sea.length; i++) {
    for (let j = i + 1; j < sea.length; j++) {
      const a = sea[i], b = sea[j];
      const bAt = new Map(b.points.map((p) => [p.ts, p]));
      const close = a.points.filter((p) => {
        const q = bAt.get(p.ts);
        return q && distanceNm(pos(p), pos(q)) <= T.MEET_NM && p.sog <= T.MEET_MAX_KN && q.sog <= T.MEET_MAX_KN;
      });
      if (!close.length) continue;
      const minutes = (ms(close[close.length - 1].ts) - ms(close[0].ts)) / 60000;
      const lastA = a.points[a.points.length - 1];
      if (minutes < T.MEET_MIN || close[close.length - 1].ts !== lastA.ts) continue;
      const area = areaOf(lastA, areas);
      if (area?.effect === 'normal_stop') continue;
      const indicators = [ind('meet', `${Math.round(minutes)} хв на відстані до ${T.MEET_NM.toString().replace('.', ',')} милі`)];
      const dark = [a, b].filter((t) => t.source === 'radar');
      if (dark.length) indicators.push(ind('partner_dark', dark.map((t) => t.name ?? t.id).join(', ')));
      if (area?.effect === 'raise') indicators.push(ind('near_critical', area.name));
      out.push(finish({ type: TYPE.MEET, trackIds: [a.id, b.id], indicators, since: close[0].ts, at: pos(lastA), areaId: area?.id ?? null }));
    }
  }
  return out;
}

// Вимкнення AIS: розрив у повідомленнях понад 5 хв. Якщо за розрив судно пройшло більше, ніж дозволяє клас, — ще й швидкість.
export function detectDark(track, classMax) {
  if (track.source !== 'ais' || track.domain !== 'sea') return null;
  const p = track.points;
  for (let i = p.length - 1; i > 0; i--) {
    const gapMin = (ms(p[i].ts) - ms(p[i - 1].ts)) / 60000;
    if (gapMin <= T.DARK_MIN) continue;
    const dist = distanceNm(pos(p[i - 1]), pos(p[i]));
    const kn = dist / (gapMin / 60);
    const indicators = [ind('dark', `${Math.round(gapMin)} хв, за цей час ${dist.toFixed(1)} милі`)];
    const max = classMax[track.kind] ?? 40;
    if (kn > max) indicators.push(ind('speed_class', `≈ ${Math.round(kn)} вуз при типових до ${max} вуз`));
    return finish({ type: TYPE.DARK, trackIds: [track.id], indicators, since: p[i - 1].ts, at: pos(p[i]), areaId: null, gapMin: Math.round(gapMin) });
  }
  return null;
}

// Стрибок: між сусідніми точками швидкість понад 100 вуз. Якщо після стрибка трек повернувся — типова підміна.
export function detectJump(track) {
  if (track.domain !== 'sea') return null;
  const p = track.points;
  for (let i = 1; i < p.length; i++) {
    const h = (ms(p[i].ts) - ms(p[i - 1].ts)) / 3600000;
    if (!h) continue;
    const d = distanceNm(pos(p[i - 1]), pos(p[i]));
    if (d / h <= T.JUMP_KN) continue;
    const indicators = [ind('jump', `${d.toFixed(0)} миль за ${Math.round(h * 60)} хв`)];
    const back = p.slice(i + 1).find((q) => ms(q.ts) - ms(p[i].ts) <= T.JUMP_RETURN_MIN * 60000 && distanceNm(pos(q), pos(p[i - 1])) < 2);
    if (back) indicators.push(ind('returned', 'трек повернувся на попередню лінію руху'));
    return finish({ type: TYPE.JUMP, trackIds: [track.id], indicators, since: p[i].ts, at: pos(p[i - 1]), areaId: null });
  }
  return null;
}

// Нетипова швидкість зараз — для суден, у яких немає розриву AIS (той випадок покриває detectDark).
export function detectSpeed(track, classMax) {
  if (track.domain !== 'sea') return null;
  const last = track.points[track.points.length - 1];
  const max = classMax[track.kind];
  if (!last || !max || last.sog <= max) return null;
  return finish({ type: TYPE.SPEED, trackIds: [track.id], indicators: [ind('speed_class', `${last.sog} вуз при типових до ${max} вуз`)], since: last.ts, at: pos(last), areaId: null });
}

// Кружляння в повітрі: сумарна зміна курсу за 10 хв понад 720°, тобто два повні кола.
export function detectAirCircle(track, areas) {
  if (track.domain !== 'air') return null;
  const pts = lastMinutes(track.points, T.CIRCLE_MIN);
  let turn = 0;
  for (let i = 1; i < pts.length; i++) turn += headingDiff(pts[i].cog, pts[i - 1].cog);
  if (turn < T.CIRCLE_DEG) return null;
  const last = pts[pts.length - 1];
  const area = areaOf(last, areas);
  const indicators = [ind('circling', `${Math.round(turn / 360)} кола за ${T.CIRCLE_MIN} хв`)];
  if (last.alt != null && last.alt < T.LOW_FT) indicators.push(ind('low', `${last.alt} футів`));
  if (area?.effect === 'normal_low') indicators.push(ind('area_approach', area.name));
  if (track.classification === 'unknown') indicators.push(ind('unknown', 'класифікація: невідомий'));
  return finish({ type: TYPE.CIRCLE, trackIds: [track.id], indicators, since: pts[0].ts, at: pos(last), areaId: area?.id ?? null });
}

export const anomalyId = (a) => `${a.type}:${a.trackIds.join('+')}`;

// Усі аномалії, що варто показати (оцінка від 15), від найвагомішої.
export function detectAll(histories, areas, classMax) {
  const found = [];
  for (const t of histories) {
    const dark = detectDark(t, classMax);
    for (const a of [detectLoiter(t, areas), dark, detectJump(t), dark ? null : detectSpeed(t, classMax), detectAirCircle(t, areas)]) {
      if (a) found.push(a);
    }
  }
  found.push(...detectMeetings(histories, areas));
  return found.filter((a) => a.score >= T.SHOW).map((a) => ({ ...a, id: anomalyId(a) })).sort((x, y) => y.score - x.score);
}
