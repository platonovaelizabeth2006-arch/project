// Геометрія району. Координати — [lon, lat] у градусах (як у GeoJSON).
// Для району розміром у десятки миль досить локальної рівнопроміжної проєкції.

const NM_PER_DEG_LAT = 60;

export function toLocalNm([lon, lat], [lon0, lat0]) {
  const k = Math.cos((lat0 * Math.PI) / 180);
  return [(lon - lon0) * NM_PER_DEG_LAT * k, (lat - lat0) * NM_PER_DEG_LAT];
}

export function fromLocalNm([x, y], [lon0, lat0]) {
  const k = Math.cos((lat0 * Math.PI) / 180);
  return [lon0 + x / (NM_PER_DEG_LAT * k), lat0 + y / NM_PER_DEG_LAT];
}

export function distanceNm(a, b) {
  const [x, y] = toLocalNm(b, a);
  return Math.hypot(x, y);
}

// Курс від a до b у градусах: 0 — північ, 90 — схід.
export function bearingDeg(a, b) {
  const [x, y] = toLocalNm(b, a);
  return (Math.atan2(x, y) * 180 / Math.PI + 360) % 360;
}

// Найменший кут між двома курсами, 0..180.
export function headingDiff(a, b) {
  const d = Math.abs(((a - b) % 360 + 360) % 360);
  return d > 180 ? 360 - d : d;
}

// Ray casting. Точка на ребрі може дати будь-який результат — для нашої
// задачі це неважливо: межа району не має товщини.
export function pointInPolygon([x, y], polygon) {
  let inside = false;
  for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
    const [xi, yi] = polygon[i];
    const [xj, yj] = polygon[j];
    if ((yi > y) !== (yj > y) && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi) {
      inside = !inside;
    }
  }
  return inside;
}

export function bounds(points) {
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  for (const [x, y] of points) {
    if (x < minX) minX = x;
    if (y < minY) minY = y;
    if (x > maxX) maxX = x;
    if (y > maxY) maxY = y;
  }
  return { minX, minY, maxX, maxY };
}
