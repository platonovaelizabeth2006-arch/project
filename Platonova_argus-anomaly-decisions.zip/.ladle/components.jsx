import '@fontsource/ibm-plex-sans/400.css';
import '@fontsource/ibm-plex-sans/600.css';
import '@fontsource/ibm-plex-mono/400.css';
import '../src/styles/tokens.css';
import '../src/styles/app.css';

// Кожна історія — на тлі сторінки ARGUS, з відступом як у .main.
export const Provider = ({ children }) => (
  <div style={{ background: 'var(--color-page)', color: 'var(--color-text)', padding: 24, minHeight: '100vh' }}>{children}</div>
);
