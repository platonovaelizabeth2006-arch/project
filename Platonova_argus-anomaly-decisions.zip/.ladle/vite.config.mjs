// Ladle збирає власним Vite 6, тому плагін React з основного vite.config.js (для Vite 8) тут не підходить.
export default { esbuild: { jsx: 'automatic' } };
