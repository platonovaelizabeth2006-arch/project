export default {
  viteConfig: '.ladle/vite.config.mjs',
  stories: 'src/**/*.stories.jsx',
  defaultStory: 'views--anomalies-data',
  addons: { theme: { enabled: false, defaultState: 'dark' }, rtl: { enabled: false } },
};
